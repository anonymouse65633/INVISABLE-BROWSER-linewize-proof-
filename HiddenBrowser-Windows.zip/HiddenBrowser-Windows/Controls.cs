namespace HiddenBrowser;

// ---------------------------------------------------------------- tab strip
public class TabStripControl : Control
{
    public class Item
    {
        public string Title = "New Tab";
        public bool Active;
    }

    public List<Item> Items = new List<Item>();
    public event Action<int> TabSelected;
    public event Action<int> TabClosed;
    public event Action NewTabClicked;
    public event Action<int, Point> TabMenu;

    int hover = -1;
    bool hoverPlus;

    public TabStripControl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
    }

    int S(int v) { return (int)Math.Round(v * DeviceDpi / 96.0); }

    float TabWidth()
    {
        int n = Math.Max(Items.Count, 1);
        int avail = Width - S(6) * 2 - S(26) - S(4);
        return Math.Max(S(40), Math.Min(S(190), (avail - S(4) * (n - 1)) / (float)n));
    }
    Rectangle TabRect(int i)
    {
        float w = TabWidth();
        return new Rectangle(S(6) + (int)(i * (w + S(4))), S(3), (int)w, Math.Max(0, Height - S(6)));
    }
    Rectangle CloseRect(Rectangle r)
    {
        return new Rectangle(r.Right - S(22), r.Top + (r.Height - S(16)) / 2, S(16), S(16));
    }
    Rectangle PlusRect()
    {
        int x = S(6) + (int)(Items.Count * (TabWidth() + S(4)));
        x = Math.Min(x, Width - S(26) - S(6));
        return new Rectangle(x, (Height - S(22)) / 2, S(26), S(22));
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Theme.Bar);
        for (int i = 0; i < Items.Count; i++)
        {
            var r = TabRect(i);
            Color bg = Items[i].Active ? Theme.Card : (i == hover ? Theme.Hover : Theme.Bar2);
            using (var br = new SolidBrush(bg)) Theme.FillRound(g, br, r, S(6));
            var textRect = new Rectangle(r.X + S(8), r.Y, Math.Max(0, r.Width - S(32)), r.Height);
            TextRenderer.DrawText(g, Items[i].Title, Theme.UI, textRect,
                Items[i].Active ? Theme.Fg : Theme.Sub,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
            TextRenderer.DrawText(g, "\uE711", Theme.IconsSmall, CloseRect(r), Theme.Sub,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
        var pr = PlusRect();
        if (hoverPlus) using (var br = new SolidBrush(Theme.Hover)) Theme.FillRound(g, br, pr, S(6));
        TextRenderer.DrawText(g, "\uE710", Theme.IconsSmall, pr, Theme.Fg,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
    }

    int HitTab(Point p)
    {
        for (int i = 0; i < Items.Count; i++) if (TabRect(i).Contains(p)) return i;
        return -1;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        int h = HitTab(e.Location);
        bool hp = PlusRect().Contains(e.Location);
        if (h != hover || hp != hoverPlus) { hover = h; hoverPlus = hp; Invalidate(); }
    }
    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        hover = -1; hoverPlus = false; Invalidate();
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        int i = HitTab(e.Location);
        if (e.Button == MouseButtons.Left)
        {
            if (i >= 0)
            {
                if (CloseRect(TabRect(i)).Contains(e.Location)) { var h = TabClosed; if (h != null) h(i); }
                else { var h = TabSelected; if (h != null) h(i); }
            }
            else if (PlusRect().Contains(e.Location)) { var h = NewTabClicked; if (h != null) h(); }
        }
        else if (e.Button == MouseButtons.Middle && i >= 0) { var h = TabClosed; if (h != null) h(i); }
        else if (e.Button == MouseButtons.Right && i >= 0) { var h = TabMenu; if (h != null) h(i, e.Location); }
    }
}

// ---------------------------------------------------------------- bookmarks bar
public class BookmarkBarControl : Control
{
    public List<Bookmark> Items = new List<Bookmark>();
    public event Action<Bookmark, bool> BookmarkClicked;     // bool = open in a new tab
    public event Action<Bookmark, Point> BookmarkMenu;
    public event Action<List<Bookmark>, Point> OverflowClicked;

    readonly List<Rectangle> rects = new List<Rectangle>();
    Rectangle overflowRect = Rectangle.Empty;
    int hiddenFrom;
    int hover = -2;   // -1 = overflow button

    public BookmarkBarControl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
    }

    int S(int v) { return (int)Math.Round(v * DeviceDpi / 96.0); }

    void DoLayout()
    {
        rects.Clear();
        hiddenFrom = Items.Count;
        overflowRect = Rectangle.Empty;
        int pad = S(8), gap = S(2), ovW = S(26);
        var widths = new List<int>();
        foreach (var b in Items)
            widths.Add(Math.Min(S(150), TextRenderer.MeasureText(b.Title, Theme.UI).Width + S(16)));
        int total = 0;
        foreach (int w in widths) total += w;
        total += gap * Math.Max(widths.Count - 1, 0);
        bool need = total > Width - pad * 2;
        int right = Width - pad - (need ? ovW + S(4) : 0);
        int x = pad;
        for (int i = 0; i < Items.Count; i++)
        {
            if (x + widths[i] > right) { hiddenFrom = i; break; }
            rects.Add(new Rectangle(x, S(3), widths[i], Math.Max(0, Height - S(6))));
            x += widths[i] + gap;
        }
        if (hiddenFrom < Items.Count)
            overflowRect = new Rectangle(Width - pad - ovW, S(3), ovW, Math.Max(0, Height - S(6)));
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Theme.Bar);
        DoLayout();
        for (int i = 0; i < rects.Count; i++)
        {
            if (i == hover) using (var br = new SolidBrush(Theme.Hover)) Theme.FillRound(g, br, rects[i], S(5));
            TextRenderer.DrawText(g, Items[i].Title, Theme.UI, rects[i], Theme.Fg,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
        }
        if (!overflowRect.IsEmpty)
        {
            if (hover == -1) using (var br = new SolidBrush(Theme.Hover)) Theme.FillRound(g, br, overflowRect, S(5));
            TextRenderer.DrawText(g, "\u00BB", Theme.Bold, overflowRect, Theme.Fg,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }

    int Hit(Point p)
    {
        DoLayout();
        if (!overflowRect.IsEmpty && overflowRect.Contains(p)) return -1;
        for (int i = 0; i < rects.Count; i++) if (rects[i].Contains(p)) return i;
        return -2;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        int h = Hit(e.Location);
        if (h != hover) { hover = h; Invalidate(); }
    }
    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        hover = -2; Invalidate();
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        int h = Hit(e.Location);
        if (h == -1)
        {
            var hidden = Items.GetRange(hiddenFrom, Items.Count - hiddenFrom);
            var ev = OverflowClicked;
            if (ev != null) ev(hidden, new Point(overflowRect.Left, Height));
        }
        else if (h >= 0)
        {
            var b = Items[h];
            if (e.Button == MouseButtons.Left)
            {
                var ev = BookmarkClicked;
                if (ev != null) ev(b, (ModifierKeys & Keys.Control) != 0);
            }
            else if (e.Button == MouseButtons.Middle)
            {
                var ev = BookmarkClicked;
                if (ev != null) ev(b, true);
            }
            else if (e.Button == MouseButtons.Right)
            {
                var ev = BookmarkMenu;
                if (ev != null) ev(b, e.Location);
            }
        }
    }
}

// ---------------------------------------------------------------- small input dialog
public class PromptDialog : Form
{
    readonly TextBox[] boxes;

    PromptDialog(string title, string[] labels, string[] initial, bool topMost)
    {
        Text = title;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterScreen;
        MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
        TopMost = topMost;
        BackColor = Theme.Bg; ForeColor = Theme.Fg; Font = Theme.UI;

        boxes = new TextBox[labels.Length];
        int y = 12;
        for (int i = 0; i < labels.Length; i++)
        {
            Controls.Add(new Label { Text = labels[i], Left = 12, Top = y, AutoSize = true, ForeColor = Theme.Fg });
            y += 22;
            var tb = new TextBox
            {
                Left = 12, Top = y, Width = 320,
                Text = (initial != null && i < initial.Length) ? initial[i] : "",
                BackColor = Theme.Card, ForeColor = Theme.Fg, BorderStyle = BorderStyle.FixedSingle
            };
            boxes[i] = tb;
            Controls.Add(tb);
            y += 32;
        }
        var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Left = 166, Top = y, Width = 80 };
        var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Left = 252, Top = y, Width = 80 };
        Controls.Add(ok); Controls.Add(cancel);
        AcceptButton = ok; CancelButton = cancel;
        ClientSize = new Size(344, y + 42);
        Shown += (s, e) => { boxes[0].Focus(); boxes[0].SelectAll(); };
    }

    public static string[] Ask(IWin32Window owner, string title, string[] labels, string[] initial = null)
    {
        bool top = owner is Form f && f.TopMost;
        using (var d = new PromptDialog(title, labels, initial, top))
        {
            if (d.ShowDialog(owner) != DialogResult.OK) return null;
            var res = new string[d.boxes.Length];
            for (int i = 0; i < res.Length; i++) res[i] = d.boxes[i].Text;
            return res;
        }
    }
}
