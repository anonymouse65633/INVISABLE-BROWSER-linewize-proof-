using System.Text.Json;
using System.Text.Json.Serialization;

namespace HiddenBrowser;

public class Bookmark
{
    public string Title { get; set; } = "";
    public string Url { get; set; } = "";
}

public class Bind
{
    public int Key { get; set; }
    public int Mods { get; set; }   // 1 = Alt, 2 = Ctrl, 4 = Shift, 8 = Win (same bits RegisterHotKey uses)

    [JsonIgnore]
    public string Display
    {
        get
        {
            string s = "";
            if ((Mods & 2) != 0) s += "Ctrl+";
            if ((Mods & 1) != 0) s += "Alt+";
            if ((Mods & 4) != 0) s += "Shift+";
            if ((Mods & 8) != 0) s += "Win+";
            return s + KeyName((Keys)Key);
        }
    }

    static string KeyName(Keys k)
    {
        switch (k)
        {
            case Keys.Oemcomma: return ",";
            case Keys.OemPeriod: return ".";
            case Keys.OemMinus: return "-";
            case Keys.Oemplus: return "=";
            case Keys.Space: return "Space";
            case Keys.Return: return "Enter";
        }
        string n = k.ToString();
        if (n.Length == 2 && n[0] == 'D' && char.IsDigit(n[1])) n = n.Substring(1);
        return n;
    }
}

public class ConfigData
{
    public Dictionary<string, bool> Flags { get; set; } = new Dictionary<string, bool>();
    public double Opacity { get; set; } = 1.0;
    public int UaIndex { get; set; } = 0;
    public int ZoomIndex { get; set; } = 2;
    public int EngineIndex { get; set; } = 0;
    public string StartPage { get; set; } = "";
    public List<Bookmark> Bookmarks { get; set; } = new List<Bookmark>();
    public Dictionary<string, Bind> Binds { get; set; } = new Dictionary<string, Bind>();
    public int[] Frame { get; set; }
    public List<string> SavedTabs { get; set; } = new List<string>();
    public int SavedTabIndex { get; set; } = 0;
    public List<string> AdAllow { get; set; } = new List<string>();    // sites where the ad blocker is paused
    public List<string> AdCustom { get; set; } = new List<string>();   // extra domains to always block
    public string AdHide { get; set; } = "";                           // extra CSS selectors to always hide
    public int AdTotal { get; set; } = 0;                              // requests blocked, all time
}

public static class Engines
{
    public static readonly (string Name, string Url)[] List =
    {
        ("Google", "https://www.google.com/search"),
        ("DuckDuckGo", "https://duckduckgo.com/"),
        ("Bing", "https://www.bing.com/search"),
    };
    public static (string Name, string Url) Current
    {
        get { return List[Math.Clamp(Prefs.EngineIndex, 0, List.Length - 1)]; }
    }
}

public static class Prefs
{
    static ConfigData d = new ConfigData();

    public static readonly string Dir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HiddenBrowser");
    static string FilePath { get { return Path.Combine(Dir, "settings.json"); } }

    public const double SeeThreshold = 80;   // see-through only works at or below this opacity (%)

    static readonly Dictionary<string, bool> FlagDefaults = new Dictionary<string, bool>
    {
        ["pauseOnHide"] = true,
        ["muteOnHide"] = false,
        ["startPinned"] = true,
        ["startHidden"] = false,
        ["hideFromCapture"] = true,
        ["neverFocus"] = false,
        ["trayIcon"] = false,
        ["seeThrough"] = false,
        ["bookmarksBar"] = true,
        ["restoreTabs"] = false,
        ["adblock"] = true,
        ["ab_ads"] = true,
        ["ab_popups"] = true,
        ["ab_trackers"] = true,
        ["ab_errors"] = true,
        ["ab_paths"] = true,
        ["ab_cosmetic"] = true,
        ["ab_youtube"] = true,
        ["ab_cookies"] = false,
        ["ab_popupwin"] = false,
        ["ab_strip"] = true,
        ["ab_dnt"] = true,
        ["hideOnBlur"] = false,
    };

    public static readonly (string Name, string Ua)[] Uas =
    {
        ("Edge (default)", ""),
        ("Chrome", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36"),
        ("Safari", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15"),
    };

    public static readonly double[] Zooms = { 0.75, 0.9, 1.0, 1.1, 1.25, 1.5 };
    public static readonly string[] ZoomNames = { "75%", "90%", "100%", "110%", "125%", "150%" };

    public static void Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                var x = JsonSerializer.Deserialize<ConfigData>(File.ReadAllText(FilePath));
                if (x != null) d = x;
            }
        }
        catch { }
    }

    public static void Save()
    {
        try
        {
            Directory.CreateDirectory(Dir);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(d, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    public static bool Flag(string k)
    {
        bool v;
        if (d.Flags.TryGetValue(k, out v)) return v;
        return FlagDefaults.TryGetValue(k, out v) && v;
    }
    public static void SetFlag(string k, bool v) { d.Flags[k] = v; Save(); }

    public static double Opacity
    {
        get { return Math.Clamp(d.Opacity, 0.3, 1.0); }
        set { d.Opacity = value; Save(); }
    }
    public static int UaIndex
    {
        get { return Math.Clamp(d.UaIndex, 0, Uas.Length - 1); }
        set { d.UaIndex = value; Save(); }
    }
    public static int ZoomIndex
    {
        get { return Math.Clamp(d.ZoomIndex, 0, Zooms.Length - 1); }
        set { d.ZoomIndex = value; Save(); }
    }
    public static int EngineIndex
    {
        get { return d.EngineIndex; }
        set { d.EngineIndex = value; Save(); }
    }
    public static string StartPage
    {
        get { return d.StartPage ?? ""; }
        set { d.StartPage = value ?? ""; Save(); }
    }

    public static List<Bookmark> Bookmarks { get { return d.Bookmarks; } }

    public static Bind GetBind(string key, Bind def)
    {
        Bind b;
        if (d.Binds.TryGetValue(key, out b)) return b;   // may be null = the user cleared it
        return def;
    }
    public static void SetBind(string key, Bind b) { d.Binds[key] = b; Save(); }

    // These change often, so the caller saves them later (MainForm.SaveSoon)
    public static int[] Frame { get { return d.Frame; } set { d.Frame = value; } }
    public static List<string> SavedTabs { get { return d.SavedTabs; } set { d.SavedTabs = value; } }
    public static int SavedTabIndex { get { return d.SavedTabIndex; } set { d.SavedTabIndex = value; } }

    // Ad blocker lists. Assign, then call Save().
    public static List<string> AdAllow { get { return d.AdAllow; } set { d.AdAllow = value ?? new List<string>(); } }
    public static List<string> AdCustom { get { return d.AdCustom; } set { d.AdCustom = value ?? new List<string>(); } }
    public static string AdHide { get { return d.AdHide ?? ""; } set { d.AdHide = value ?? ""; } }
    public static int AdTotal { get { return d.AdTotal; } set { d.AdTotal = value; } }
}
