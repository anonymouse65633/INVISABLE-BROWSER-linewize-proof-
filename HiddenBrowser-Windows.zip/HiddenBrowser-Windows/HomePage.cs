namespace HiddenBrowser;

static class HomePage
{
    // JavaScript injected into every page: forwards keyboard shortcuts to the app
    public const string KeyScript = """
(function () {
  if (window.__hbk) return; window.__hbk = 1;
  function post(m) { try { window.chrome.webview.postMessage('k:' + m); } catch (e) {} }
  document.addEventListener('keydown', function (e) {
    var c = e.ctrlKey, s = e.shiftKey, a = e.altKey, k = (e.key || '').toLowerCase(), cmd = null;
    if (c && !a) {
      if (!s) {
        switch (k) {
          case 'l': cmd = 'focus-address'; break;
          case 'r': cmd = 'reload'; break;
          case 'd': cmd = 'bookmark'; break;
          case 'w': cmd = 'close-tab'; break;
          case 't': cmd = 'new-tab'; break;
          case 'f': cmd = 'find'; break;
          case 'g': cmd = 'find-next'; break;
          case ',': cmd = 'settings'; break;
          case '=': case '+': cmd = 'zoom-in'; break;
          case '-': cmd = 'zoom-out'; break;
          case '0': cmd = 'zoom-reset'; break;
          case 'tab': cmd = 'next-tab'; break;
          default: if (k.length === 1 && k >= '1' && k <= '9') cmd = 'tab-' + k;
        }
      } else {
        switch (k) {
          case 't': cmd = 'reopen-tab'; break;
          case 'h': cmd = 'home'; break;
          case 'b': cmd = 'toggle-bm'; break;
          case 'w': cmd = 'hide'; break;
          case 'f': cmd = 'cover'; break;
          case '+': cmd = 'zoom-in'; break;
          case 'tab': cmd = 'prev-tab'; break;
          case ']': case '}': cmd = 'next-tab'; break;
          case '[': case '{': cmd = 'prev-tab'; break;
        }
      }
    } else if (a && !c && !s) {
      if (k === 'arrowleft') cmd = 'back'; else if (k === 'arrowright') cmd = 'forward';
    } else if (!c && !a && !s) {
      if (k === 'f5') cmd = 'reload'; else if (k === 'escape') cmd = 'escape';
    }
    if (cmd) {
      if (cmd !== 'escape') { e.preventDefault(); e.stopPropagation(); }
      post(cmd);
    }
  }, true);
})();
""";

    public const string Template = """
<!doctype html>
<html><head><meta charset="utf-8"><title>Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root { color-scheme: light dark; --bg:#fff; --fg:#202124; --card:#f1f3f4; --card2:#e8eaed; --sub:#5f6368; }
  @media (prefers-color-scheme: dark) { :root { --bg:#202124; --fg:#e8eaed; --card:#303134; --card2:#3c4043; --sub:#9aa0a6; } }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--fg); font-family: "Segoe UI", system-ui, sans-serif;
         display:flex; flex-direction:column; align-items:center; padding:7vh 24px 24px; min-height:100vh; }
  h1 { font-weight:500; font-size:34px; margin:0 0 22px; letter-spacing:-.5px; }
  form { width:100%; max-width:560px; margin-bottom:30px; }
  input[type=text] { width:100%; padding:13px 20px; border-radius:26px; border:1px solid transparent; outline:none;
         background:var(--card); color:var(--fg); font-size:15px; }
  input[type=text]:focus { background:var(--card2); }
  .hint { opacity:.6; font-size:13px; margin:0 0 12px; }
  .grid { display:flex; flex-wrap:wrap; gap:14px; justify-content:center; max-width:640px; }
  .tile { position:relative; width:104px; padding:14px 8px 10px; border-radius:14px; background:var(--card);
          text-decoration:none; color:var(--fg); text-align:center; }
  .tile:hover { background:var(--card2); }
  .ic { width:44px; height:44px; border-radius:50%; background:var(--card2); margin:0 auto 8px;
        display:flex; align-items:center; justify-content:center; font-size:20px; font-weight:600; }
  .t { font-size:12px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .x { position:absolute; top:3px; right:5px; border:0; background:none; color:var(--sub); font-size:16px;
       cursor:pointer; display:none; line-height:1; }
  .tile:hover .x { display:block; }
  .add .ic { font-size:24px; color:var(--sub); }
</style></head>
<body>
  <h1>%%ENGINE_NAME%%</h1>
  <form action="%%ENGINE_URL%%" method="get">
    <input type="text" name="q" placeholder="Search or type a URL" autofocus autocomplete="off">
  </form>
  %%HINT%%
  <div class="grid">
    %%TILES%%
    <a class="tile add" href="#" id="add"><div class="ic">+</div><div class="t">Add</div></a>
  </div>
<script>
  function send(m) { window.chrome.webview.postMessage(m); }
  document.querySelector('form').addEventListener('submit', function (e) {
    var v = document.querySelector('input[name=q]').value.trim();
    var hasScheme = v.indexOf('://') > 0;
    if (hasScheme || (v.indexOf('.') > 0 && v.indexOf(' ') < 0)) {
      e.preventDefault();
      window.location.href = hasScheme ? v : 'https://' + v;
    }
  });
  document.getElementById('add').addEventListener('click', function (e) { e.preventDefault(); send('add'); });
  var xs = document.querySelectorAll('.x');
  for (var i = 0; i < xs.length; i++) {
    xs[i].addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      send('rm:' + this.getAttribute('data-url'));
    });
  }
</script>
</body></html>
""";
}
