using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Web.WebView2.Core;

namespace HiddenBrowser;

// Built-in ad / tracker blocker (generated from one shared list so Mac and Windows match).
//  1. Network:  requests to listed hosts (by category), your own "always block" domains, and ad files
//               that give themselves away in the path are refused before they are sent.
//  2. Cosmetic: leftover ad boxes (and optionally cookie banners and your own selectors) are hidden.
//  3. YouTube:  video ads are skipped as soon as they start.
//  4. Privacy:  tracking codes are stripped from links; Do Not Track / Global Privacy Control is sent.
static class AdBlock
{
    public static readonly string[] Categories = { "ads", "popups", "trackers", "errors" };

    static readonly Dictionary<string, string[]> ListsByCat = new Dictionary<string, string[]>
    {
        ["ads"] = new[]
        {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "pagead2.googlesyndication.com",
            "2mdn.net", "googletagservices.com", "admob.com", "adnxs.com", "adsrvr.org",
            "advertising.com", "adform.net", "adition.com", "amazon-adsystem.com", "rubiconproject.com",
            "pubmatic.com", "openx.net", "casalemedia.com", "indexww.com", "contextweb.com",
            "smartadserver.com", "criteo.com", "criteo.net", "media.net", "yieldmo.com",
            "33across.com", "sharethrough.com", "teads.tv", "triplelift.com", "lijit.com",
            "sovrn.com", "gumgum.com", "bidswitch.net", "improvedigital.com", "adcolony.com",
            "mopub.com", "inmobi.com", "smaato.net", "serving-sys.com", "sizmek.com",
            "flashtalking.com", "zedo.com", "adtech.de", "adsymptotic.com", "yahoo-ads.com",
            "ads.yahoo.com", "advertising.yahooinc.com", "gemini.yahoo.com", "taboola.com", "outbrain.com",
            "revcontent.com", "mgid.com", "zemanta.com", "content.ad", "outbrainimg.com",
            "taboolasyndication.com", "adskeeper.com", "adblade.com", "bidvertiser.com", "adroll.com",
            "rfihub.com", "adzerk.net", "buysellads.com", "carbonads.com", "carbonads.net",
            "rtbhouse.com", "onetag-sys.com", "emxdgt.com", "adgrx.com", "cpmstar.com",
            "pubmine.com", "adscale.de", "ml314.com",
        },
        ["popups"] = new[]
        {
            "popads.net", "popcash.net", "propellerads.com", "exoclick.com", "exosrv.com",
            "juicyads.com", "trafficjunky.net", "adsterra.com", "hilltopads.net", "clickadu.com",
            "adcash.com", "onclickads.net", "popunderjs.com", "revenuehits.com", "trafficfactory.biz",
            "a-ads.com", "ad-maven.com", "admaven.com",
        },
        ["trackers"] = new[]
        {
            "moatads.com", "adsafeprotected.com", "doubleverify.com", "scorecardresearch.com", "imrworldwide.com",
            "quantserve.com", "quantcount.com", "bluekai.com", "krxd.net", "demdex.net",
            "everesttech.net", "rlcdn.com", "liadm.com", "agkn.com", "tapad.com",
            "mathtag.com", "turn.com", "w55c.net", "bidr.io", "crwdcntrl.net",
            "eyeota.net", "exelator.com", "mxpnl.com", "mixpanel.com", "google-analytics.com",
            "analytics.google.com", "googletagmanager.com", "ssl.google-analytics.com", "hotjar.com", "hotjar.io",
            "segment.com", "segment.io", "amplitude.com", "heapanalytics.com", "mouseflow.com",
            "crazyegg.com", "clarity.ms", "mc.yandex.ru", "mc.yandex.com", "statcounter.com",
            "chartbeat.com", "chartbeat.net", "parsely.com", "omtrdc.net", "2o7.net",
            "kissmetrics.com", "matomo.cloud", "luckyorange.com", "inspectlet.com", "smartlook.com",
            "pendo.io", "branch.io", "bat.bing.com", "ads.linkedin.com", "snap.licdn.com",
            "analytics.twitter.com", "ads-twitter.com", "analytics.tiktok.com", "ads.tiktok.com", "ct.pinterest.com",
            "analytics.yahoo.com", "sc-static.net", "fullstory.com",
        },
        ["errors"] = new[]
        {
            "bugsnag.com", "d2wy8f7a9ursnm.cloudfront.net", "sentry.io", "sentry-cdn.com", "rollbar.com",
            "raygun.io", "trackjs.com", "errorception.com", "airbrake.io", "logrocket.com",
            "logrocket.io", "lr-ingest.io", "newrelic.com", "nr-data.net", "datadoghq-browser-agent.com",
            "browser-intake-datadoghq.com", "honeybadger.io", "loggly.com", "bugherd.com",
        },
    };

    static readonly Dictionary<string, string> DomainCat = BuildDomainMap();

    static Dictionary<string, string> BuildDomainMap()
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var kv in ListsByCat)
            foreach (var h in kv.Value)
                if (!d.ContainsKey(h)) d[h] = kv.Key;
        return d;
    }

    // never apply the file-path rules to these (Microsoft + Google's own sites)
    static readonly string[] SafeSuffixes = { "google.com", "gstatic.com", "microsoft.com", "microsoftonline.com", "office.com", "office365.com", "live.com", "sharepoint.com", "cloud.microsoft", "azure.com", "windows.net", "msauth.net", "msftauth.net" };

    // ad files that give themselves away in the path (images and scripts only)
    static readonly Regex PathRx = new Regex(
        @"(^|[/_.\-])(ads|adv|advert|adverts|advertisement|advertisements|adserver|adbanner|adbanners|ad_banner|ad-banner|ad_banners|ad-banners|banner_ads|banner-ads|bannerads|banner_ad|banner-ad|googleads|pagead|adframe|adsense|textads|text_ads|text-ads|textad|adimage|adimages|adimg|adimgs|adpic|adunit|adslot|adspace|adzone|adview|adclick|adsimg|advimg|ad_img|ad-img)([/_.\-]|$)|[/_.\-]ads[0-9]",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    // ad-looking images: /ad/, /ad_x.gif, ad300x250.png, banner sizes such as 728x90
    static readonly Regex ImageRx = new Regex(
        @"(^|/)ad(/|\.(gif|jpe?g|png|webp)$)|(^|/)ad[_\-]|[/_.\-]ad[0-9]|[/_.\-](468x60|728x90|300x250|336x280|160x600|120x600|300x600|970x90|970x250|320x50|234x60|120x240|125x125)([._\-]|$)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    static readonly HashSet<string> TrackParams = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id", "utm_name", "utm_reader", "utm_cid", "fbclid", "gclid", "gclsrc", "dclid", "gbraid", "wbraid", "msclkid", "mc_eid", "mc_cid", "igshid", "yclid", "twclid", "ttclid", "li_fat_id", "_ga", "_gl", "mkt_tok", "vero_id", "oly_enc_id", "oly_anon_id", "rb_clickid", "s_cid", "ef_id", "ref_src", "ref_url"
    };

    // ------------------------------------------------------------ statistics
    public static readonly Dictionary<string, int> Counts = new Dictionary<string, int>();
    public static int Total;
    public static bool Dirty;

    public static void Hit(string cat)
    {
        int n;
        Counts.TryGetValue(cat, out n);
        Counts[cat] = n + 1;
        Total++;
        Prefs.AdTotal++;
        Dirty = true;
    }

    public static void ResetCounts()
    {
        Counts.Clear();
        Total = 0;
        Dirty = true;
    }

    // ------------------------------------------------------------ domain helpers
    public static string NormalizeDomain(string s)
    {
        s = (s ?? "").Trim().ToLowerInvariant();
        int i = s.IndexOf("://", StringComparison.Ordinal);
        if (i >= 0) s = s.Substring(i + 3);
        i = s.IndexOfAny(new[] { '/', '?', '#' });
        if (i >= 0) s = s.Substring(0, i);
        i = s.IndexOf(':');
        if (i >= 0) s = s.Substring(0, i);
        return s.TrimStart('*', '.');
    }

    public static List<string> ParseDomains(string text)
    {
        var result = new List<string>();
        foreach (var part in (text ?? "").Split(new[] { '\n', '\r', ',', ' ', ';', '\t' }, StringSplitOptions.RemoveEmptyEntries))
        {
            string d = NormalizeDomain(part);
            if (d.Length > 0 && d.Contains('.') && !result.Contains(d)) result.Add(d);
        }
        return result;
    }

    public static string[] SplitLines(string text)
    {
        var result = new List<string>();
        foreach (var line in (text ?? "").Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries))
        {
            string l = line.Trim();
            if (l.Length > 0) result.Add(l);
        }
        return result.ToArray();
    }

    static bool MatchesAny(string host, List<string> domains)
    {
        foreach (var d in domains)
            if (host.Equals(d, StringComparison.OrdinalIgnoreCase) || host.EndsWith("." + d, StringComparison.OrdinalIgnoreCase))
                return true;
        return false;
    }

    public static bool IsAllowed(string host)
    {
        return !string.IsNullOrEmpty(host) && MatchesAny(host, Prefs.AdAllow);
    }

    static bool IsSafeHost(string host)
    {
        foreach (var s in SafeSuffixes)
            if (host.Equals(s, StringComparison.OrdinalIgnoreCase) || host.EndsWith("." + s, StringComparison.OrdinalIgnoreCase))
                return true;
        return false;
    }

    static bool SameSite(string a, string b)
    {
        if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b)) return false;
        return a.Equals(b, StringComparison.OrdinalIgnoreCase) ||
               a.EndsWith("." + b, StringComparison.OrdinalIgnoreCase) ||
               b.EndsWith("." + a, StringComparison.OrdinalIgnoreCase);
    }

    // ------------------------------------------------------------ the decision
    // Returns the category that blocked the request ("ads", "popups", "trackers", "errors", "custom", "paths"), or null to allow.
    public static string Classify(Uri u, CoreWebView2WebResourceContext ctx, string pageHost)
    {
        if (!Prefs.Flag("adblock")) return null;
        string host = u.Host;
        if (IsAllowed(pageHost)) return null;
        if (SameSite(host, pageHost)) return null;   // you're on that site on purpose

        if (Prefs.AdCustom.Count > 0 && MatchesAny(host, Prefs.AdCustom)) return "custom";

        string h = host;
        while (true)
        {
            string cat;
            if (DomainCat.TryGetValue(h, out cat)) return Prefs.Flag("ab_" + cat) ? cat : null;
            int i = h.IndexOf('.');
            if (i < 0 || i == h.Length - 1) break;
            h = h.Substring(i + 1);
        }

        if (Prefs.Flag("ab_paths") && !IsSafeHost(host))
        {
            string path = u.AbsolutePath;
            if (path.EndsWith(".swf", StringComparison.OrdinalIgnoreCase)) return "paths";
            if ((ctx == CoreWebView2WebResourceContext.Image || ctx == CoreWebView2WebResourceContext.Script) && PathRx.IsMatch(path)) return "paths";
            if (ctx == CoreWebView2WebResourceContext.Image && ImageRx.IsMatch(path)) return "paths";
        }
        return null;
    }

    // ------------------------------------------------------------ tracking codes in links
    // Returns the cleaned address, or null if there was nothing to remove.
    public static string StripTracking(string url)
    {
        Uri u;
        if (!Uri.TryCreate(url, UriKind.Absolute, out u) || (u.Scheme != "http" && u.Scheme != "https")) return null;
        string q = u.Query;
        if (q.Length < 2) return null;
        var keep = new List<string>();
        bool removed = false;
        foreach (var p in q.Substring(1).Split('&'))
        {
            if (p.Length == 0) continue;
            int i = p.IndexOf('=');
            string k;
            try { k = Uri.UnescapeDataString(i >= 0 ? p.Substring(0, i) : p); } catch { k = p; }
            if (TrackParams.Contains(k)) removed = true; else keep.Add(p);
        }
        if (!removed) return null;
        var b = new UriBuilder(u);
        b.Query = string.Join("&", keep);
        return b.Uri.AbsoluteUri;
    }

    // ------------------------------------------------------------ page script
    public static string BuildScript()
    {
        bool on = Prefs.Flag("adblock");
        var cfg = new
        {
            cosmetic = on && Prefs.Flag("ab_cosmetic"),
            youtube = on && Prefs.Flag("ab_youtube"),
            cookies = on && Prefs.Flag("ab_cookies"),
            dnt = Prefs.Flag("ab_dnt"),
            allow = Prefs.AdAllow.ToArray(),
            custom = SplitLines(Prefs.AdHide)
        };
        return ScriptTemplate.Replace("/*CONFIG*/null", JsonSerializer.Serialize(cfg));
    }

    const string ScriptTemplate = """
(function () {
  var HB = /*CONFIG*/null;
  var host = location.hostname;
  for (var i = 0; i < HB.allow.length; i++) {
    var a = HB.allow[i];
    if (host === a || host.endsWith('.' + a)) return;
  }
  if (HB.dnt) {
    try {
      Object.defineProperty(Navigator.prototype, 'globalPrivacyControl', { get: function () { return true; }, configurable: true });
      Object.defineProperty(Navigator.prototype, 'doNotTrack', { get: function () { return '1'; }, configurable: true });
    } catch (e) {}
  }
  var sels = [];
  if (HB.cosmetic) sels = sels.concat(['.adsbygoogle', 'ins.adsbygoogle', '[id^="google_ads_"]', '[id^="div-gpt-ad"]', '[id^="gpt-ad"]', 'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]', 'iframe[id^="google_ads_iframe"]', '[aria-label="Advertisement"]', '[aria-label="advertisement"]', '[data-ad-slot]', '[data-ad-client]', '.ad-banner', '.ad-container', '.ad-slot', '.ad-wrapper', '.advert', '.advertisement', '.ad-box', '.adsbox', '.ad-placement', '.ad_unit', '#ad_unit', '.ad-leaderboard', '.banner_ad', '.banner-ads', '.bannerAd', '.adBanner', '#adBanner', '#google_ads', '.text-ads', '.textads', '.sponsor-ad', '.promoted-ad', '.top-ad', '.sidebar-ad', '.widget-ad', '.pub_300x250', '.pub_728x90', '.pub_300x250m', '.afs_ads', '.adlink', '.ads-container', '.ads-wrapper', '.ad-unit', '[class*="adsbox"]', '[id*="adsbox"]', '.sponsored-ad', '.sponsored-content', '#ad-banner', '#ad_banner', '#ads-banner', '#advertisement', '.taboola', '#taboola-below-article', '.OUTBRAIN', '.ob-widget', '[id^="taboola-"]', 'img[src*="/ads/"]', 'img[src*="/adbanner"]', 'img[src*="ad_banner"]', 'img[src*="ad-banner"]', 'img[src*="banner_ad"]', 'img[src*="/adimages/"]', 'iframe[src*="/ads/"]', 'iframe[src*="/adframe"]', 'embed[src*=".swf"]', 'object[data*=".swf"]', '#masthead-ad', 'ytd-ad-slot-renderer', 'ytd-in-feed-ad-layout-renderer', 'ytd-banner-promo-renderer', 'ytd-promoted-sparkles-web-renderer', 'ytd-display-ad-renderer', 'ytd-companion-slot-renderer', '.ytp-ad-overlay-container', '.ytp-ad-module']);
  if (HB.cookies) sels = sels.concat(['#onetrust-banner-sdk', '#onetrust-consent-sdk', '#CybotCookiebotDialog', '#CybotCookiebotDialogBodyUnderlay', '.cc-window', '.cc-banner', '#cookie-law-info-bar', '#cookieconsent', '.cookie-banner', '.cookie-notice', '#cookie-notice', '#cookie-banner', '.cookiebanner', '.qc-cmp2-container', '#qc-cmp2-container', '.truste_overlay', '#truste-consent-track', '.fc-consent-root', '[id^="sp_message_container"]', '.osano-cm-window', '#usercentrics-root', '#didomi-host', '.didomi-popup-container', '#cookiescript_injected', '.evidon-banner', '#iubenda-cs-banner', '.iubenda-cs-container']);
  if (HB.custom && HB.custom.length) sels = sels.concat(HB.custom);

  function addStyle() {
    if (!sels.length) return;
    try {
      var st = document.createElement('style');
      (document.head || document.documentElement).appendChild(st);
      var sh = st.sheet;
      for (var j = 0; j < sels.length; j++) {
        try { sh.insertRule(sels[j] + '{display:none !important}', sh.cssRules.length); } catch (e) {}
      }
    } catch (e) {}
  }
  if (document.documentElement) addStyle();
  else document.addEventListener('DOMContentLoaded', addStyle);

  // YouTube video ads: skip them the moment they start
  if (HB.youtube && /(^|\.)youtube\.com$/.test(host)) {
    var mutedByUs = false;
    setInterval(function () {
      var player = document.querySelector('.html5-video-player');
      var video = document.querySelector('video.html5-main-video') || document.querySelector('video');
      if (player && video && player.classList.contains('ad-showing')) {
        if (!video.muted) { video.muted = true; mutedByUs = true; }
        if (isFinite(video.duration) && video.duration > 0) video.currentTime = video.duration;
        var skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button');
        if (skip) skip.click();
      } else if (mutedByUs && video) {
        video.muted = false; mutedByUs = false;
      }
      var closers = document.querySelectorAll('.ytp-ad-overlay-close-button');
      for (var k = 0; k < closers.length; k++) closers[k].click();
    }, 250);
  }
})();
""";
}
