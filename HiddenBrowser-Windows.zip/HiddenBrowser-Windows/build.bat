@echo off
setlocal enabledelayedexpansion
title HiddenBrowser - install and build
cd /d "%~dp0"

echo ============================================================
echo   HiddenBrowser: one-click install + build
echo   Installs what is missing, builds the app, and puts
echo   HiddenBrowser.exe in your Downloads folder.
echo ============================================================
echo.

rem ---------- 1. winget (needed to install things) ----------
where winget >nul 2>nul
if errorlevel 1 set "NOWINGET=1"

rem ---------- 2. .NET 8 SDK ----------
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"
set "HAVE_SDK="
dotnet --list-sdks 2>nul | findstr /b "8\." >nul && set "HAVE_SDK=1"
if not defined HAVE_SDK if exist "%ProgramFiles%\dotnet\dotnet.exe" (
  set "PATH=%ProgramFiles%\dotnet;%PATH%"
  dotnet --list-sdks 2>nul | findstr /b "8\." >nul && set "HAVE_SDK=1"
)
if not defined HAVE_SDK (
  if defined NOWINGET (
    echo Could not find winget, so the .NET 8 SDK can't be installed automatically.
    echo Install it from https://dotnet.microsoft.com/download/dotnet/8.0 and run this file again.
    pause
    exit /b 1
  )
  echo [1/4] Installing the .NET 8 SDK ^(a Windows prompt may ask for permission^)...
  winget install -e --id Microsoft.DotNet.SDK.8 --accept-source-agreements --accept-package-agreements
  set "PATH=%ProgramFiles%\dotnet;%PATH%"
  dotnet --list-sdks 2>nul | findstr /b "8\." >nul
  if errorlevel 1 (
    echo.
    echo The .NET 8 SDK still isn't available. Close this window, open a new one, and run this file again.
    pause
    exit /b 1
  )
) else (
  echo [1/4] .NET 8 SDK is installed.
)

rem ---------- 3. WebView2 runtime ----------
set "HAVE_WV2="
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>nul && set "HAVE_WV2=1"
reg query "HKLM\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>nul && set "HAVE_WV2=1"
reg query "HKCU\Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>nul && set "HAVE_WV2=1"
if not defined HAVE_WV2 (
  if defined NOWINGET (
    echo [2/4] The WebView2 Runtime is missing. Get it from https://developer.microsoft.com/microsoft-edge/webview2
  ) else (
    echo [2/4] Installing the Edge WebView2 Runtime...
    winget install -e --id Microsoft.EdgeWebView2Runtime --accept-source-agreements --accept-package-agreements
  )
) else (
  echo [2/4] WebView2 Runtime is installed.
)

rem ---------- 4. build one self-contained exe ----------
set "RID=win-x64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "RID=win-arm64"
set "OUT=%TEMP%\HiddenBrowser_build"
if exist "%OUT%" rmdir /s /q "%OUT%"
taskkill /im HiddenBrowser.exe >nul 2>nul

echo [3/4] Building ^(first time takes a few minutes while it downloads packages^)...
dotnet publish HiddenBrowser.csproj -c Release -r %RID% --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -o "%OUT%"
if errorlevel 1 (
  echo.
  echo The build failed. Copy the red error lines above and send them over.
  pause
  exit /b 1
)

rem ---------- 5. copy to Downloads ----------
set "DL="
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "(New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path" 2^>nul`) do set "DL=%%D"
if not defined DL set "DL=%USERPROFILE%\Downloads"
if not exist "%DL%" mkdir "%DL%"
copy /y "%OUT%\HiddenBrowser.exe" "%DL%\HiddenBrowser.exe" >nul
if errorlevel 1 (
  echo Could not copy the exe to %DL%.
  pause
  exit /b 1
)

echo [4/4] Done!
echo.
echo   Your app is here:  %DL%\HiddenBrowser.exe
echo.
explorer /select,"%DL%\HiddenBrowser.exe"
start "" "%DL%\HiddenBrowser.exe"
timeout /t 5 >nul
exit /b 0
