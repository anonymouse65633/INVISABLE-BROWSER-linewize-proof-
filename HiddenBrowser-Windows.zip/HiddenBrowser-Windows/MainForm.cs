using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using WfTimer = System.Windows.Forms.Timer;

namespace HiddenBrowser;

public class BrowserTab
{
    public WebView2 Web;
    public string Title = "New Tab";
    public string Url = "";
    public bool IsHome;
    public bool HomePending;
    public string AdScriptId;          // id of the injected ad-blocker script (so it can be replaced)
    public string PageHost = "";       // host of the page being loaded (for the per-site pause list)
    public string LastClean = "";      // last link we removed tracking codes from
    public DateTime LastStripAt = DateTime.MinValue;
}

public class BindAction
{
    public int Id;
    public string Key;
    public string Title;
    public Bind Def;
    public Action Run;
}

public partial class MainForm : Form
{
    // ------------------------------------------------------------------ state
    CoreWebView2Environment env;
    readonly List<BrowserTab> tabs = new List<BrowserTab>();
    int cur;
    readonly List<string> closedTabs = new List<string>();
    string lastFind = "";
    static string defaultUA;

    bool following, covering, clickThrough, tabsReady, mutedByUs, settingsOpen, ignoring, startHiddenPending;
    Rectangle preCover;
    IVirtualDesktopManager vdm;
    bool vdmFailed;

    // UI
    TableLayoutPanel layout;
    Button btnBack, btnFwd, btnReload, btnHome, btnStar, btnShield, btnPin, btnHide, btnGear;
    TextBox address;
    TabStripControl tabStrip;
    BookmarkBarControl bmBar;
    Panel webHost;
    ToolTip tips;
    NotifyIcon tray;
    WfTimer mouseTimer, saveTimer, slowTimer, vdTimer;

    readonly List<BindAction> actions = new List<BindAction>();
    readonly Dictionary<int, bool> hotOk = new Dictionary<int, bool>();

    int S(int v) { return (int)Math.Round(v * DeviceDpi / 96.0); }

    BrowserTab CurTab { get { return (cur >= 0 && cur < tabs.Count) ? tabs[cur] : null; } }
    CoreWebView2 Core { get { var t = CurTab; return t == null ? null : t.Web.CoreWebView2; } }
    bool AllowKey { get { return !Prefs.Flag("neverFocus") || settingsOpen; } }

    // ------------------------------------------------------------------ construction
    public MainForm()
    {
        Prefs.Load();
        Theme.Init();

        AutoScaleMode = AutoScaleMode.None;
        Text = "Home";
        Font = Theme.UI;
        BackColor = Theme.Bg;
        ForeColor = Theme.Fg;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        MinimumSize = new Size(S(320), S(240));
        following = Prefs.Flag("startPinned");
        TopMost = following;

        BuildActions();
        BuildUi();
        BuildSettings();
        RestoreFrame();

        startHiddenPending = Prefs.Flag("startHidden") &&
            (Prefs.GetBind("toggle", new Bind { Key = (int)Keys.H, Mods = 3 }) != null || Prefs.Flag("trayIcon"));

        mouseTimer = new WfTimer { Interval = 33 };
        mouseTimer.Tick += (s, e) => TickMouse();
        mouseTimer.Start();

        saveTimer = new WfTimer { Interval = 600 };
        saveTimer.Tick += (s, e) => { saveTimer.Stop(); Prefs.Save(); };

        slowTimer = new WfTimer { Interval = 3000 };
        slowTimer.Tick += (s, e) =>
        {
            RetryHotkeys();
            if (AdBlock.Dirty) { AdBlock.Dirty = false; Prefs.Save(); }
            if (settingsOpen) UpdateAdStats();
        };
        slowTimer.Start();

        vdTimer = new WfTimer { Interval = 400 };
        vdTimer.Tick += (s, e) => { if (following && Visible) EnsureOnCurrentDesktop(); };
        vdTimer.Start();

        UpdateTray();
        UpdateFollowButton();

        Deactivate += (s, e) =>
        {
            if (!Prefs.Flag("hideOnBlur")) return;
            BeginInvoke(new Action(() =>
            {
                // only when you clicked away to another program (not a dialog or menu of ours)
                if (Visible && ActiveForm == null && !settingsOpen && !covering && !clickThrough && !SeeThroughActive)
                    HideWindow();
            }));
        };
    }

    void BuildActions()
    {
        int id = 1;
        Action<string, string, Keys, Action> add = (key, title, k, run) =>
            actions.Add(new BindAction { Id = id++, Key = key, Title = title, Def = new Bind { Key = (int)k, Mods = 3 }, Run = run });
        add("toggle", "Show / hide window", Keys.H, () => ToggleVisible());
        add("panic", "Panic hide (pauses + mutes)", Keys.D, () => HideWindow(true));
        add("follow", "Pin on top", Keys.F, () => ToggleFollow());
        add("cover", "Cover the screen", Keys.G, () => ToggleCover());
        add("clickthrough", "Click-through (whole window)", Keys.C, () => ToggleClickThrough());
        add("typing", "Never-focus mode", Keys.T, () => ToggleNeverFocus());
        foreach (var a in actions) hotOk[a.Id] = false;
    }

    // ------------------------------------------------------------------ UI
    Button IconButton(string glyph, string tip, Action click)
    {
        var b = new Button
        {
            Text = glyph, Font = Theme.Icons, FlatStyle = FlatStyle.Flat, Dock = DockStyle.Fill,
            Margin = Padding.Empty, TabStop = false, BackColor = Theme.Bar, ForeColor = Theme.Fg,
            UseVisualStyleBackColor = false
        };
        b.FlatAppearance.BorderSize = 0;
        b.FlatAppearance.MouseOverBackColor = Theme.Hover;
        b.FlatAppearance.MouseDownBackColor = Theme.Card;
        b.Click += (s, e) => click();
        tips.SetToolTip(b, tip);
        return b;
    }

    void BuildUi()
    {
        tips = new ToolTip();

        layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, BackColor = Theme.Bg,
            Margin = Padding.Empty, Padding = Padding.Empty
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, S(38)));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, S(30)));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, S(28)));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        // toolbar
        var tb = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 10, RowCount = 1, BackColor = Theme.Bar,
            Margin = Padding.Empty, Padding = new Padding(S(6), 0, S(6), 0)
        };
        for (int i = 0; i < 4; i++) tb.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, S(32)));
        tb.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (int i = 0; i < 5; i++) tb.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, S(32)));
        tb.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        btnBack = IconButton("\uE72B", "Back (Alt+Left)", () => { var c = Core; if (c != null && c.CanGoBack) c.GoBack(); });
        btnFwd = IconButton("\uE72A", "Forward (Alt+Right)", () => { var c = Core; if (c != null && c.CanGoForward) c.GoForward(); });
        btnReload = IconButton("\uE72C", "Reload (Ctrl+R)", () => DoReload());
        btnHome = IconButton("\uE80F", "Home (Ctrl+Shift+H)", () => { if (CurTab != null) ShowHome(CurTab); });
        btnStar = IconButton("\uE734", "Add bookmark (Ctrl+D)", () => ToggleBookmark());
        btnShield = IconButton("AD", "Ad blocker", () => ShowShieldMenu());
        btnShield.Font = new Font("Segoe UI", 8f, FontStyle.Bold);
        btnPin = IconButton("\uE718", "Pin on top", () => ToggleFollow());
        btnHide = IconButton("\uE7B3", "Hide window", () => HideWindow());
        btnGear = IconButton("\uE713", "Settings (Ctrl+,)", () => ToggleSettings());

        address = new TextBox
        {
            Anchor = AnchorStyles.Left | AnchorStyles.Right, BackColor = Theme.Card, ForeColor = Theme.Fg,
            BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10f),
            Margin = new Padding(S(4), 0, S(4), 0), PlaceholderText = "Search or enter address"
        };
        address.KeyDown += (s, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Go(); }
        };

        tb.Controls.Add(btnBack, 0, 0);
        tb.Controls.Add(btnFwd, 1, 0);
        tb.Controls.Add(btnReload, 2, 0);
        tb.Controls.Add(btnHome, 3, 0);
        tb.Controls.Add(address, 4, 0);
        tb.Controls.Add(btnStar, 5, 0);
        tb.Controls.Add(btnShield, 6, 0);
        tb.Controls.Add(btnPin, 7, 0);
        tb.Controls.Add(btnHide, 8, 0);
        tb.Controls.Add(btnGear, 9, 0);

        tabStrip = new TabStripControl { Dock = DockStyle.Fill, Margin = Padding.Empty };
        tabStrip.TabSelected += i => SelectTab(i);
        tabStrip.TabClosed += i => CloseTab(i);
        tabStrip.NewTabClicked += () => NewTabAction();
        tabStrip.TabMenu += (i, p) => ShowTabMenu(i, p);

        bmBar = new BookmarkBarControl { Dock = DockStyle.Fill, Margin = Padding.Empty };
        bmBar.BookmarkClicked += (b, newTab) =>
        {
            if (newTab) { var _ = NewTabAsync(b.Url, false, false); }
            else if (CurTab != null && CurTab.Web.CoreWebView2 != null)
            {
                CurTab.Web.CoreWebView2.Navigate(b.Url);
                if (AllowKey) CurTab.Web.Focus();
            }
        };
        bmBar.BookmarkMenu += (b, p) =>
        {
            var m = new ContextMenuStrip();
            m.Items.Add("Open in New Tab", null, (s, e) => { var _ = NewTabAsync(b.Url); });
            m.Items.Add("Remove Bookmark", null, (s, e) => { BookmarkRemove(b.Url); BookmarksChanged(); });
            m.Show(bmBar, p);
        };
        bmBar.OverflowClicked += (list, p) =>
        {
            var m = new ContextMenuStrip();
            foreach (var b in list)
            {
                var bb = b;
                m.Items.Add(bb.Title, null, (s, e) => { var _ = NewTabAsync(bb.Url); });
            }
            m.Show(bmBar, p);
        };

        webHost = new Panel { Dock = DockStyle.Fill, Margin = Padding.Empty, BackColor = Theme.Bg };

        layout.Controls.Add(tb, 0, 0);
        layout.Controls.Add(tabStrip, 0, 1);
        layout.Controls.Add(bmBar, 0, 2);
        layout.Controls.Add(webHost, 0, 3);
        Controls.Add(layout);
    }

    // ------------------------------------------------------------------ window plumbing
    protected override CreateParams CreateParams
    {
        get
        {
            var cp = base.CreateParams;
            cp.ExStyle |= (int)Native.WS_EX_LAYERED;
            if (!AllowKey) cp.ExStyle |= (int)Native.WS_EX_NOACTIVATE;
            return cp;
        }
    }

    protected override bool ShowWithoutActivation { get { return !AllowKey; } }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        ignoring = false;
        ApplyOpacity();
        ApplyCapture();
        int dark = Theme.Dark ? 1 : 0;
        Native.DwmSetWindowAttribute(Handle, 20, ref dark, sizeof(int));
        RegisterBinds();
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        InitBrowser();
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        base.OnFormClosing(e);
        SaveTabs();
        var r = covering ? preCover : Bounds;
        Prefs.Frame = new[] { r.X, r.Y, r.Width, r.Height };
        Prefs.Save();
        foreach (var a in actions) Native.UnregisterHotKey(Handle, a.Id);
        if (tray != null) { tray.Visible = false; tray.Dispose(); }
    }

    protected override void OnLocationChanged(EventArgs e) { base.OnLocationChanged(e); NoteFrame(); }
    protected override void OnSizeChanged(EventArgs e) { base.OnSizeChanged(e); NoteFrame(); }

    void NoteFrame()
    {
        if (!IsHandleCreated || covering || WindowState != FormWindowState.Normal || !Visible) return;
        Prefs.Frame = new[] { Bounds.X, Bounds.Y, Bounds.Width, Bounds.Height };
        SaveSoon();
    }

    void SaveSoon() { if (saveTimer != null) { saveTimer.Stop(); saveTimer.Start(); } }

    void RestoreFrame()
    {
        var f = Prefs.Frame;
        if (f != null && f.Length == 4 && f[2] >= S(320) && f[3] >= S(240))
        {
            var r = new Rectangle(f[0], f[1], f[2], f[3]);
            foreach (var scr in Screen.AllScreens)
            {
                if (scr.WorkingArea.IntersectsWith(r)) { Bounds = r; return; }
            }
        }
        ResetFrame();
    }

    void ResetFrame()
    {
        var wa = Screen.PrimaryScreen.WorkingArea;
        int w = S(640), h = S(460);
        Bounds = new Rectangle(wa.Left + (wa.Width - w) / 2, wa.Top + (wa.Height - h) / 2, w, h);
    }

    void ApplyOpacity()
    {
        if (!IsHandleCreated) return;
        byte a = startHiddenPending ? (byte)0 : (byte)Math.Round(255 * Math.Clamp(Prefs.Opacity, 0.3, 1.0));
        Native.SetLayeredWindowAttributes(Handle, 0, a, Native.LWA_ALPHA);
    }

    void ApplyCapture()
    {
        if (!IsHandleCreated) return;
        Native.SetWindowDisplayAffinity(Handle, Prefs.Flag("hideFromCapture") ? Native.WDA_EXCLUDEFROMCAPTURE : Native.WDA_NONE);
    }

    void ApplyKeyPolicy()
    {
        if (!IsHandleCreated) return;
        long ex = Native.GetExStyle(Handle);
        ex = AllowKey ? (ex & ~Native.WS_EX_NOACTIVATE) : (ex | Native.WS_EX_NOACTIVATE);
        Native.SetExStyle(Handle, ex);
        if (AllowKey && Visible) Activate();
    }

    // ------------------------------------------------------------------ global hotkeys
    void RegisterBinds()
    {
        if (!IsHandleCreated) return;
        foreach (var a in actions)
        {
            Native.UnregisterHotKey(Handle, a.Id);
            hotOk[a.Id] = false;
            var b = Prefs.GetBind(a.Key, a.Def);
            if (b != null) hotOk[a.Id] = Native.RegisterHotKey(Handle, a.Id, (uint)b.Mods | Native.MOD_NOREPEAT, (uint)b.Key);
        }
        UpdateHotStatus();
    }

    void RetryHotkeys()
    {
        if (!IsHandleCreated) return;
        bool changed = false;
        foreach (var a in actions)
        {
            var b = Prefs.GetBind(a.Key, a.Def);
            if (b != null && !hotOk[a.Id])
            {
                hotOk[a.Id] = Native.RegisterHotKey(Handle, a.Id, (uint)b.Mods | Native.MOD_NOREPEAT, (uint)b.Key);
                if (hotOk[a.Id]) changed = true;
            }
        }
        if (changed) UpdateHotStatus();
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == Native.WM_HOTKEY)
        {
            int id = m.WParam.ToInt32();
            foreach (var a in actions) if (a.Id == id) { a.Run(); break; }
            return;
        }
        base.WndProc(ref m);
    }

    // ------------------------------------------------------------------ show / hide / modes
    void PauseAll()
    {
        foreach (var t in tabs)
        {
            var c = t.Web.CoreWebView2;
            if (c != null) { var _ = c.ExecuteScriptAsync("document.querySelectorAll('video,audio').forEach(function(e){e.pause()})"); }
        }
    }

    void SetMuted(bool m)
    {
        foreach (var t in tabs) { var c = t.Web.CoreWebView2; if (c != null) c.IsMuted = m; }
    }

    void HideWindow(bool force = false)
    {
        if (force || Prefs.Flag("pauseOnHide")) PauseAll();
        if (force || Prefs.Flag("muteOnHide")) { SetMuted(true); mutedByUs = true; }
        Hide();
    }

    void ShowWindow()
    {
        if (startHiddenPending) { startHiddenPending = false; ApplyOpacity(); }
        if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        Show();
        TopMost = following;
        if (mutedByUs) { SetMuted(false); mutedByUs = false; }
        if (AllowKey) Activate();
    }

    void ToggleVisible()
    {
        if (Visible && WindowState != FormWindowState.Minimized) HideWindow(); else ShowWindow();
    }

    void ToggleFollow()
    {
        following = !following;
        TopMost = following;
        UpdateFollowButton();
        if (covering) { var scr = Screen.FromControl(this); Bounds = following ? scr.Bounds : scr.WorkingArea; }
    }

    void UpdateFollowButton()
    {
        if (btnPin == null) return;
        btnPin.Text = following ? "\uE840" : "\uE718";
        btnPin.ForeColor = following ? Theme.Accent : Theme.Fg;
        tips.SetToolTip(btnPin, following ? "Pinned on top (stays on your current desktop)" : "Pin on top");
    }

    void ToggleCover()
    {
        if (covering)
        {
            covering = false;
            Bounds = preCover;
        }
        else
        {
            preCover = Bounds;
            covering = true;
            var scr = Screen.FromControl(this);
            Bounds = following ? scr.Bounds : scr.WorkingArea;
        }
    }

    void ToggleClickThrough()
    {
        clickThrough = !clickThrough;
        TickMouse();
    }

    void ToggleNeverFocus()
    {
        Prefs.SetFlag("neverFocus", !Prefs.Flag("neverFocus"));
        ApplyKeyPolicy();
        SyncSettings();
    }

    void SnapCorner(int corner)
    {
        var wa = Screen.FromControl(this).WorkingArea;
        int m = S(12);
        int x = (corner == 0 || corner == 2) ? wa.Left + m : wa.Right - Width - m;
        int y = (corner == 0 || corner == 1) ? wa.Top + m : wa.Bottom - Height - m;
        Location = new Point(x, y);
    }

    // Keeps the pinned window on whichever virtual desktop you switch to
    void EnsureOnCurrentDesktop()
    {
        if (vdmFailed || !IsHandleCreated) return;
        try
        {
            if (vdm == null) vdm = (IVirtualDesktopManager)new CVirtualDesktopManager();
            bool on;
            if (vdm.IsWindowOnCurrentVirtualDesktop(Handle, out on) != 0 || on) return;
            IntPtr fg = Native.GetForegroundWindow();
            if (fg == IntPtr.Zero) return;
            Guid id;
            if (vdm.GetWindowDesktopId(fg, out id) != 0 || id == Guid.Empty) return;
            vdm.MoveWindowToDesktop(Handle, ref id);
        }
        catch { vdmFailed = true; }
    }

    // ------------------------------------------------------------------ see-through / click-through
    bool SeeThroughActive { get { return Prefs.Flag("seeThrough") && Prefs.Opacity * 100.0 <= Prefs.SeeThreshold; } }

    Rectangle StripRect()
    {
        int top = webHost.PointToScreen(Point.Empty).Y;
        return new Rectangle(Left, Top, Width, Math.Max(0, top - Top));
    }

    bool ShouldIgnoreMouse()
    {
        if (clickThrough) return true;
        if (!SeeThroughActive) return false;
        if (settingsOpen) return false;
        if ((ModifierKeys & Keys.Alt) != 0) return false;
        if (Control.MouseButtons != MouseButtons.None) return ignoring;   // don't change mode mid-click
        return !StripRect().Contains(Cursor.Position);
    }

    void SetIgnore(bool v)
    {
        if (v == ignoring || !IsHandleCreated) return;
        ignoring = v;
        long ex = Native.GetExStyle(Handle);
        ex = v ? (ex | Native.WS_EX_LAYERED | Native.WS_EX_TRANSPARENT) : (ex & ~Native.WS_EX_TRANSPARENT);
        Native.SetExStyle(Handle, ex);
    }

    void TickMouse()
    {
        if (!IsHandleCreated || !Visible) return;
        SetIgnore(ShouldIgnoreMouse());
    }

    // ------------------------------------------------------------------ keyboard shortcuts (inside the window)
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (activeRec != null) return HandleRecorderKey(keyData);
        if (HandleKeys(keyData)) return true;
        return base.ProcessCmdKey(ref msg, keyData);
    }

    bool HandleKeys(Keys keyData)
    {
        Keys key = keyData & Keys.KeyCode;
        Keys mods = keyData & Keys.Modifiers;
        bool ctrl = (mods & Keys.Control) != 0, shift = (mods & Keys.Shift) != 0, alt = (mods & Keys.Alt) != 0;
        string cmd = null;

        if (ctrl && !alt)
        {
            if (!shift)
            {
                switch (key)
                {
                    case Keys.L: cmd = "focus-address"; break;
                    case Keys.R: cmd = "reload"; break;
                    case Keys.D: cmd = "bookmark"; break;
                    case Keys.W: cmd = "close-tab"; break;
                    case Keys.T: cmd = "new-tab"; break;
                    case Keys.F: cmd = "find"; break;
                    case Keys.G: cmd = "find-next"; break;
                    case Keys.Oemcomma: cmd = "settings"; break;
                    case Keys.Oemplus: cmd = "zoom-in"; break;
                    case Keys.OemMinus: cmd = "zoom-out"; break;
                    case Keys.D0: cmd = "zoom-reset"; break;
                    case Keys.Tab: cmd = "next-tab"; break;
                    default:
                        if (key >= Keys.D1 && key <= Keys.D9) cmd = "tab-" + ((int)key - (int)Keys.D0);
                        break;
                }
            }
            else
            {
                switch (key)
                {
                    case Keys.T: cmd = "reopen-tab"; break;
                    case Keys.H: cmd = "home"; break;
                    case Keys.B: cmd = "toggle-bm"; break;
                    case Keys.W: cmd = "hide"; break;
                    case Keys.F: cmd = "cover"; break;
                    case Keys.Oemplus: cmd = "zoom-in"; break;
                    case Keys.Tab: cmd = "prev-tab"; break;
                    case Keys.Oem6: cmd = "next-tab"; break;
                    case Keys.Oem4: cmd = "prev-tab"; break;
                }
            }
        }
        else if (alt && !ctrl && !shift)
        {
            if (key == Keys.Left) cmd = "back";
            else if (key == Keys.Right) cmd = "forward";
        }
        else if (!ctrl && !alt && !shift)
        {
            if (key == Keys.F5) cmd = "reload";
            else if (key == Keys.Escape && covering) cmd = "escape";
        }

        if (cmd == null) return false;
        RunCommand(cmd);
        return true;
    }

    void RunCommand(string cmd)
    {
        switch (cmd)
        {
            case "focus-address": FocusAddress(); break;
            case "reload": DoReload(); break;
            case "bookmark": ToggleBookmark(); break;
            case "close-tab": CloseTabAction(); break;
            case "new-tab": NewTabAction(); break;
            case "find": FindInPage(); break;
            case "find-next": FindNext(); break;
            case "settings": ToggleSettings(); break;
            case "zoom-in": Zoom(0.1); break;
            case "zoom-out": Zoom(-0.1); break;
            case "zoom-reset": if (CurTab != null) CurTab.Web.ZoomFactor = Prefs.Zooms[Prefs.ZoomIndex]; break;
            case "next-tab": StepTab(1); break;
            case "prev-tab": StepTab(-1); break;
            case "reopen-tab": ReopenTab(); break;
            case "home": if (CurTab != null) ShowHome(CurTab); break;
            case "toggle-bm": ToggleBookmarksBar(); break;
            case "hide": HideWindow(); break;
            case "cover": ToggleCover(); break;
            case "escape": if (covering) ToggleCover(); break;
            case "back": { var c = Core; if (c != null && c.CanGoBack) c.GoBack(); break; }
            case "forward": { var c = Core; if (c != null && c.CanGoForward) c.GoForward(); break; }
            default:
                int n;
                if (cmd.StartsWith("tab-") && int.TryParse(cmd.Substring(4), out n)) SelectTabNumber(n);
                break;
        }
    }

    // ------------------------------------------------------------------ browser init
    async void InitBrowser()
    {
        try
        {
            var opts = new CoreWebView2EnvironmentOptions(additionalBrowserArguments: "--autoplay-policy=no-user-gesture-required");
            string dataDir = Path.Combine(Prefs.Dir, "WebView2");
            env = await CoreWebView2Environment.CreateAsync(null, dataDir, opts);
        }
        catch (Exception ex)
        {
            MessageBox.Show("HiddenBrowser needs the Microsoft Edge WebView2 Runtime.\n\n" +
                "Install it from https://developer.microsoft.com/microsoft-edge/webview2 and start the app again.\n\n" + ex.Message,
                "HiddenBrowser", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Application.Exit();
            return;
        }

        RefreshBookmarksBar();

        var saved = Prefs.Flag("restoreTabs") ? new List<string>(Prefs.SavedTabs) : new List<string>();
        int savedIdx = Prefs.SavedTabIndex;
        if (saved.Count > 0)
        {
            for (int i = 0; i < saved.Count; i++)
                await NewTabAsync(string.IsNullOrEmpty(saved[i]) ? null : saved[i], i == 0, true);
            SelectTab(Math.Clamp(savedIdx, 0, tabs.Count - 1));
        }
        else
        {
            string start = string.IsNullOrWhiteSpace(Prefs.StartPage) ? null : Resolve(Prefs.StartPage);
            await NewTabAsync(start, true, true);
        }

        tabsReady = true;
        SaveTabs();

        if (startHiddenPending)
        {
            Hide();
            startHiddenPending = false;
            ApplyOpacity();
        }
    }

    // ------------------------------------------------------------------ tabs
    async Task<BrowserTab> NewTabAsync(string url = null, bool select = true, bool home = true)
    {
        var t = new BrowserTab();
        t.Web = new WebView2 { Dock = DockStyle.Fill, DefaultBackgroundColor = Theme.Bg };
        webHost.Controls.Add(t.Web);
        if (!select && tabs.Count > 0) t.Web.SendToBack(); else t.Web.BringToFront();
        settingsPanel.BringToFront();

        await t.Web.EnsureCoreWebView2Async(env);
        InitTab(t);

        tabs.Add(t);
        if (select || tabs.Count == 1) SelectTab(tabs.Count - 1);
        else { t.Web.Visible = false; RefreshStrip(); }

        if (url != null) t.Web.CoreWebView2.Navigate(url);
        else if (home) ShowHome(t);
        TabChanged(t);
        return t;
    }

    void InitTab(BrowserTab t)
    {
        var core = t.Web.CoreWebView2;
        if (defaultUA == null) defaultUA = core.Settings.UserAgent;
        core.Settings.AreBrowserAcceleratorKeysEnabled = false;   // we handle shortcuts ourselves
        core.Settings.IsStatusBarEnabled = false;
        ApplyUA(t);
        t.Web.ZoomFactor = Prefs.Zooms[Prefs.ZoomIndex];

        var k = core.AddScriptToExecuteOnDocumentCreatedAsync(HomePage.KeyScript);
        RefreshAdScript(t);

        // ad blocker: refuse requests to known ad / tracker hosts, and send Do Not Track
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        core.WebResourceRequested += (s, e) =>
        {
            Uri u;
            if (!Uri.TryCreate(e.Request.Uri, UriKind.Absolute, out u)) return;
            if (u.Scheme != "http" && u.Scheme != "https") return;

            string pageHost = t.PageHost;
            if (Prefs.Flag("ab_dnt") && !AdBlock.IsAllowed(pageHost))
            {
                e.Request.Headers.SetHeader("DNT", "1");
                e.Request.Headers.SetHeader("Sec-GPC", "1");
            }
            string cat = AdBlock.Classify(u, e.ResourceContext, pageHost);
            if (cat != null)
            {
                AdBlock.Hit(cat);
                e.Response = env.CreateWebResourceResponse(new MemoryStream(), 403, "Blocked", "");
            }
        };

        core.SourceChanged += (s, e) => TabChanged(t);
        core.DocumentTitleChanged += (s, e) => TabChanged(t);
        core.HistoryChanged += (s, e) => TabChanged(t);
        core.NavigationStarting += (s, e) =>
        {
            bool isData = e.Uri.StartsWith("data:text/html", StringComparison.OrdinalIgnoreCase);
            Uri nav;
            bool isWeb = Uri.TryCreate(e.Uri, UriKind.Absolute, out nav) && (nav.Scheme == "http" || nav.Scheme == "https");

            // remove tracking codes (utm_*, fbclid, gclid ...) from the address, once
            if (isWeb && Prefs.Flag("ab_strip") && !e.IsRedirected && !AdBlock.IsAllowed(nav.Host))
            {
                string clean = AdBlock.StripTracking(e.Uri);
                if (clean != null && !(clean == t.LastClean && (DateTime.UtcNow - t.LastStripAt).TotalSeconds < 5))
                {
                    t.LastClean = clean;
                    t.LastStripAt = DateTime.UtcNow;
                    e.Cancel = true;
                    BeginInvoke(new Action(() => { var cc = t.Web.CoreWebView2; if (cc != null) cc.Navigate(clean); }));
                    return;
                }
            }
            if (isWeb) t.PageHost = nav.Host;
            t.IsHome = t.HomePending || isData;
            t.HomePending = false;
        };
        core.WebMessageReceived += (s, e) => OnWebMessage(t, e);
        core.NewWindowRequested += async (s, e) =>
        {
            // optional: drop pop-up windows that open without a click
            if (Prefs.Flag("adblock") && Prefs.Flag("ab_popupwin") && !e.IsUserInitiated && !AdBlock.IsAllowed(t.PageHost))
            {
                e.Handled = true;
                AdBlock.Hit("popups");
                return;
            }
            var d = e.GetDeferral();
            try
            {
                var nt = await NewTabAsync(null, true, false);
                e.NewWindow = nt.Web.CoreWebView2;
                e.Handled = true;
            }
            catch { }
            finally { d.Complete(); }
        };
        core.ProcessFailed += (s, e) =>
        {
            if (e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessExited) core.Reload();
        };
    }

    void ApplyUA(BrowserTab t)
    {
        var core = t.Web.CoreWebView2;
        if (core == null) return;
        string ua = Prefs.Uas[Prefs.UaIndex].Ua;
        core.Settings.UserAgent = string.IsNullOrEmpty(ua) ? defaultUA : ua;
    }

    void OnWebMessage(BrowserTab t, CoreWebView2WebMessageReceivedEventArgs e)
    {
        string s;
        try { s = e.TryGetWebMessageAsString(); } catch { return; }
        if (string.IsNullOrEmpty(s)) return;
        if (s.StartsWith("k:")) { RunCommand(s.Substring(2)); return; }
        if (!t.IsHome) return;   // only our own Home page may edit bookmarks
        if (s == "add") PromptAddBookmark();
        else if (s.StartsWith("rm:")) { BookmarkRemove(s.Substring(3)); BookmarksChanged(); }
    }

    void SelectTab(int i)
    {
        if (i < 0 || i >= tabs.Count) return;
        cur = i;
        for (int j = 0; j < tabs.Count; j++) tabs[j].Web.Visible = (j == i);
        tabs[i].Web.BringToFront();
        settingsPanel.BringToFront();
        RefreshStrip();
        TabChanged(tabs[i]);
        if (AllowKey && !settingsOpen && tabs[i].Web.CoreWebView2 != null && Visible) tabs[i].Web.Focus();
    }

    void SelectTabNumber(int n) { SelectTab(n >= 9 ? tabs.Count - 1 : n - 1); }

    void StepTab(int delta)
    {
        if (tabs.Count > 1) SelectTab((cur + delta + tabs.Count) % tabs.Count);
    }

    void CloseTab(int i)
    {
        if (i < 0 || i >= tabs.Count) return;
        var t = tabs[i];
        tabs.RemoveAt(i);
        if (!t.IsHome && t.Url.StartsWith("http"))
        {
            closedTabs.Add(t.Url);
            if (closedTabs.Count > 20) closedTabs.RemoveAt(0);
        }
        webHost.Controls.Remove(t.Web);
        t.Web.Dispose();
        if (tabs.Count == 0) { var _ = NewTabAsync(); return; }
        if (i < cur) cur--;
        else if (i == cur) cur = Math.Min(i, tabs.Count - 1);
        SelectTab(cur);
    }

    void CloseTabAction()
    {
        if (tabs.Count > 1) CloseTab(cur); else HideWindow();
    }

    void CloseOtherTabs(int keepIndex)
    {
        if (keepIndex < 0 || keepIndex >= tabs.Count) return;
        var keep = tabs[keepIndex];
        for (int j = tabs.Count - 1; j >= 0; j--) if (tabs[j] != keep) CloseTab(j);
    }

    void DuplicateTab(int i)
    {
        if (i < 0 || i >= tabs.Count) return;
        var t = tabs[i];
        if (!t.IsHome && t.Url.StartsWith("http")) { var _ = NewTabAsync(t.Url); }
        else { var _ = NewTabAsync(); }
    }

    void ReopenTab()
    {
        if (closedTabs.Count == 0) { System.Media.SystemSounds.Beep.Play(); return; }
        string u = closedTabs[closedTabs.Count - 1];
        closedTabs.RemoveAt(closedTabs.Count - 1);
        var _ = NewTabAsync(u);
    }

    async void NewTabAction()
    {
        await NewTabAsync();
        FocusAddress();
    }

    void ShowTabMenu(int i, Point p)
    {
        var m = new ContextMenuStrip();
        m.Items.Add("Duplicate Tab", null, (s, e) => DuplicateTab(i));
        m.Items.Add("Close Tab", null, (s, e) => CloseTab(i));
        m.Items.Add("Close Other Tabs", null, (s, e) => CloseOtherTabs(i));
        m.Show(tabStrip, p);
    }

    void RefreshStrip()
    {
        tabStrip.Items.Clear();
        for (int i = 0; i < tabs.Count; i++)
            tabStrip.Items.Add(new TabStripControl.Item { Title = tabs[i].Title, Active = (i == cur) });
        tabStrip.Invalidate();
    }

    void TabChanged(BrowserTab t)
    {
        var core = t.Web.CoreWebView2;
        string url = "";
        if (!t.IsHome)
        {
            var src = t.Web.Source;
            if (src != null && src.Scheme != "about" && src.Scheme != "data") url = src.AbsoluteUri;
        }
        string title = t.IsHome ? "Home" : (core != null ? core.DocumentTitle : "");
        if (string.IsNullOrEmpty(title))
        {
            if (url.Length > 0)
            {
                string host = t.Web.Source != null ? t.Web.Source.Host : "";
                title = string.IsNullOrEmpty(host) ? url : host;
            }
            else title = "New Tab";
        }
        t.Title = title;
        t.Url = url;

        int idx = tabs.IndexOf(t);
        if (idx >= 0 && idx < tabStrip.Items.Count)
        {
            tabStrip.Items[idx].Title = title;
            tabStrip.Invalidate();
        }
        SaveTabs();

        if (t != CurTab) return;
        if (!address.Focused) address.Text = url;
        Text = title;
        btnBack.Enabled = core != null && core.CanGoBack;
        btnFwd.Enabled = core != null && core.CanGoForward;
        UpdateStar();
        UpdateShield();
    }

    void SaveTabs()
    {
        if (!tabsReady) return;
        if (Prefs.Flag("restoreTabs"))
        {
            var list = new List<string>();
            foreach (var t in tabs) list.Add((!t.IsHome && t.Url.StartsWith("http")) ? t.Url : "");
            Prefs.SavedTabs = list;
            Prefs.SavedTabIndex = cur;
        }
        else if (Prefs.SavedTabs.Count > 0) Prefs.SavedTabs = new List<string>();
        SaveSoon();
    }

    // ------------------------------------------------------------------ navigation
    string Resolve(string input)
    {
        string s = (input ?? "").Trim();
        if (s.Length == 0) return null;
        if (!s.Contains("://"))
        {
            if (s.Contains('.') && !s.Contains(' ')) s = "https://" + s;
            else s = Engines.Current.Url + "?q=" + Uri.EscapeDataString(s);
        }
        Uri u;
        return Uri.TryCreate(s, UriKind.Absolute, out u) ? u.AbsoluteUri : null;
    }

    void Go()
    {
        string u = Resolve(address.Text);
        if (u == null || Core == null) return;
        Core.Navigate(u);
        if (AllowKey) CurTab.Web.Focus();
    }

    void DoReload()
    {
        var t = CurTab;
        if (t == null) return;
        if (t.IsHome) ShowHome(t);
        else if (t.Web.CoreWebView2 != null) t.Web.CoreWebView2.Reload();
    }

    void FocusAddress()
    {
        if (!AllowKey) return;
        Activate();
        address.Focus();
        address.SelectAll();
    }

    void Zoom(double delta)
    {
        var t = CurTab;
        if (t != null) t.Web.ZoomFactor = Math.Clamp(t.Web.ZoomFactor + delta, 0.3, 3.0);
    }

    void ShowHome(BrowserTab t)
    {
        if (t == null || t.Web.CoreWebView2 == null) return;
        t.HomePending = true;
        t.IsHome = true;
        t.Web.CoreWebView2.NavigateToString(HomeHtml());
        TabChanged(t);
    }

    string HomeHtml()
    {
        var tiles = new System.Text.StringBuilder();
        foreach (var b in Prefs.Bookmarks)
        {
            string letter = b.Title.Length > 0 ? b.Title.Substring(0, 1).ToUpperInvariant() : "?";
            string u = System.Net.WebUtility.HtmlEncode(b.Url);
            tiles.Append("<a class=\"tile\" href=\"" + u + "\"><button class=\"x\" data-url=\"" + u +
                "\" title=\"Remove\">&times;</button><div class=\"ic\"><span>" + System.Net.WebUtility.HtmlEncode(letter) +
                "</span></div><div class=\"t\">" + System.Net.WebUtility.HtmlEncode(b.Title) + "</div></a>");
        }
        var eng = Engines.Current;
        string hint = tiles.Length == 0 ? "<p class='hint'>No bookmarks yet. Press Ctrl+D on any page to add one.</p>" : "";
        return HomePage.Template
            .Replace("%%TILES%%", tiles.ToString())
            .Replace("%%HINT%%", hint)
            .Replace("%%ENGINE_URL%%", System.Net.WebUtility.HtmlEncode(eng.Url))
            .Replace("%%ENGINE_NAME%%", System.Net.WebUtility.HtmlEncode(eng.Name));
    }

    // ------------------------------------------------------------------ ad blocker controls
    async void RefreshAdScript(BrowserTab t)
    {
        try
        {
            var core = t.Web.CoreWebView2;
            if (core == null) return;
            if (t.AdScriptId != null) { core.RemoveScriptToExecuteOnDocumentCreated(t.AdScriptId); t.AdScriptId = null; }
            t.AdScriptId = await core.AddScriptToExecuteOnDocumentCreatedAsync(AdBlock.BuildScript());
        }
        catch { }
    }

    void RefreshAllAdScripts()
    {
        foreach (var t in tabs) RefreshAdScript(t);
    }

    string CurrentHost()
    {
        var t = CurTab;
        if (t == null || t.IsHome || !t.Url.StartsWith("http")) return "";
        Uri u;
        return Uri.TryCreate(t.Url, UriKind.Absolute, out u) ? u.Host : "";
    }

    void ToggleAllowHost(string host)
    {
        host = AdBlock.NormalizeDomain(host);
        if (host.Length == 0) return;
        var list = new List<string>(Prefs.AdAllow);
        if (list.Contains(host)) list.Remove(host); else list.Add(host);
        Prefs.AdAllow = list;
        Prefs.Save();
        RefreshAllAdScripts();
        UpdateShield();
        SyncSettings();
        if (CurTab != null && !CurTab.IsHome) DoReload();
    }

    void UpdateShield()
    {
        if (btnShield == null) return;
        bool on = Prefs.Flag("adblock");
        bool paused = AdBlock.IsAllowed(CurrentHost());
        btnShield.ForeColor = (on && !paused) ? Theme.Accent : Theme.Sub;
        string host = CurrentHost();
        tips.SetToolTip(btnShield, !on ? "Ad blocker is off"
            : paused ? "Ad blocker is paused on " + host
            : "Ad blocker on - blocked " + AdBlock.Total + " this session");
        if (adSiteBtn != null)
        {
            adSiteBtn.Text = host.Length == 0 ? "Pause ad blocker on this site (open a page first)"
                : (paused ? "Turn ad blocker back on for " + host : "Pause ad blocker on " + host);
            adSiteBtn.Enabled = host.Length > 0;
        }
    }

    void ShowShieldMenu()
    {
        string host = CurrentHost();
        bool on = Prefs.Flag("adblock");
        bool paused = AdBlock.IsAllowed(host);
        var m = new ContextMenuStrip();
        var master = new ToolStripMenuItem(on ? "Turn ad blocker off" : "Turn ad blocker on");
        master.Click += (s, e) => { OnPref("adblock", !on); UpdateShield(); SyncSettings(); };
        m.Items.Add(master);
        var site = new ToolStripMenuItem(host.Length == 0 ? "Pause on this site" : (paused ? "Turn back on for " + host : "Pause on " + host));
        site.Enabled = host.Length > 0 && on;
        site.Click += (s, e) => ToggleAllowHost(host);
        m.Items.Add(site);
        m.Items.Add("-");
        var stats = new ToolStripMenuItem("Blocked this session: " + AdBlock.Total);
        stats.Enabled = false;
        m.Items.Add(stats);
        m.Items.Add("Ad blocker settings...", null, (s, e) => OpenAdSettings());
        m.Show(btnShield, new Point(0, btnShield.Height));
    }

    void OpenAdSettings()
    {
        if (!settingsOpen) ToggleSettings();
        if (adHeader != null) settingsPanel.ScrollControlIntoView(adHeader);
    }

    // ------------------------------------------------------------------ find in page
    void FindInPage()
    {
        var r = PromptDialog.Ask(this, "Find in page", new[] { "Find:" }, new[] { lastFind });
        if (r == null) return;
        lastFind = r[0];
        FindNext();
    }

    void FindNext()
    {
        if (lastFind.Length == 0) { FindInPage(); return; }
        var c = Core;
        if (c == null) return;
        string arg = JsonSerializer.Serialize(lastFind);
        var _ = c.ExecuteScriptAsync("window.find(" + arg + ", false, false, true)");
    }

    // ------------------------------------------------------------------ bookmarks
    static string Norm(string s)
    {
        s = (s ?? "").Trim();
        int i = s.IndexOf('#');
        if (i >= 0) s = s.Substring(0, i);
        return s.TrimEnd('/');
    }

    bool BookmarkContains(string url)
    {
        string n = Norm(url);
        foreach (var b in Prefs.Bookmarks) if (Norm(b.Url) == n) return true;
        return false;
    }

    void BookmarkRemove(string url)
    {
        string n = Norm(url);
        Prefs.Bookmarks.RemoveAll(b => Norm(b.Url) == n);
        Prefs.Save();
    }

    void ToggleBookmark()
    {
        var t = CurTab;
        if (t == null || t.IsHome || !t.Url.StartsWith("http")) { System.Media.SystemSounds.Beep.Play(); return; }
        if (BookmarkContains(t.Url)) BookmarkRemove(t.Url);
        else
        {
            string title = t.Title.Length > 24 ? t.Title.Substring(0, 24) : t.Title;
            Prefs.Bookmarks.Add(new Bookmark { Title = title, Url = t.Url });
            Prefs.Save();
        }
        BookmarksChanged();
    }

    void PromptAddBookmark()
    {
        var r = PromptDialog.Ask(this, "Add bookmark", new[] { "Name:", "Address:" }, new[] { "", "" });
        if (r == null) return;
        string name = r[0].Trim();
        string u = Resolve(r[1]);
        if (u == null) return;
        if (name.Length == 0) name = new Uri(u).Host;
        if (!BookmarkContains(u)) { Prefs.Bookmarks.Add(new Bookmark { Title = name, Url = u }); Prefs.Save(); }
        BookmarksChanged();
    }

    void BookmarksChanged()
    {
        RefreshBookmarksBar();
        UpdateStar();
        var t = CurTab;
        if (t != null && t.IsHome) ShowHome(t);
    }

    void RefreshBookmarksBar()
    {
        bool show = Prefs.Flag("bookmarksBar");
        layout.RowStyles[2].Height = show ? S(28) : 0;
        bmBar.Visible = show;
        bmBar.Items = new List<Bookmark>(Prefs.Bookmarks);
        bmBar.Invalidate();
    }

    void ToggleBookmarksBar()
    {
        Prefs.SetFlag("bookmarksBar", !Prefs.Flag("bookmarksBar"));
        RefreshBookmarksBar();
        SyncSettings();
    }

    void UpdateStar()
    {
        var t = CurTab;
        bool ok = t != null && !t.IsHome && t.Url.StartsWith("http");
        bool marked = ok && BookmarkContains(t.Url);
        btnStar.Text = marked ? "\uE735" : "\uE734";
        btnStar.Enabled = ok;
        btnStar.ForeColor = marked ? Theme.Accent : Theme.Fg;
        tips.SetToolTip(btnStar, marked ? "Remove bookmark (Ctrl+D)" : "Add bookmark (Ctrl+D)");
    }

    // ------------------------------------------------------------------ tray icon
    void UpdateTray()
    {
        if (Prefs.Flag("trayIcon"))
        {
            if (tray == null)
            {
                var menu = new ContextMenuStrip();
                menu.Items.Add("Show / Hide", null, (s, e) => ToggleVisible());
                menu.Items.Add("Pin on top", null, (s, e) => ToggleFollow());
                menu.Items.Add("Cover screen", null, (s, e) => ToggleCover());
                menu.Items.Add("Settings", null, (s, e) => { ShowWindow(); if (!settingsOpen) ToggleSettings(); });
                menu.Items.Add("-");
                menu.Items.Add("Quit", null, (s, e) => Close());
                tray = new NotifyIcon { Icon = System.Drawing.SystemIcons.Application, Text = "HiddenBrowser", ContextMenuStrip = menu };
                tray.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) ToggleVisible(); };
            }
            tray.Visible = true;
        }
        else if (tray != null) tray.Visible = false;
    }

    // ------------------------------------------------------------------ browsing data
    async void ClearBrowsingData()
    {
        var ans = MessageBox.Show(this, "Clear cookies, cache and site data? You will be signed out of sites.",
            "Clear browsing data", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
        if (ans != DialogResult.OK) return;
        var c = Core;
        if (c == null) return;
        await c.Profile.ClearBrowsingDataAsync();
        closedTabs.Clear();
        Prefs.SavedTabs = new List<string>();
        Prefs.Save();
        if (CurTab != null) ShowHome(CurTab);
    }
}
