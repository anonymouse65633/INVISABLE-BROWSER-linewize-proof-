namespace HiddenBrowser;

static class Program
{
    [STAThread]
    static void Main()
    {
        // Only one copy at a time
        using var mutex = new Mutex(true, "HiddenBrowser.SingleInstance", out bool first);
        if (!first) return;

        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}
