using Microsoft.Win32;

namespace HiddenBrowser;

public class BindRecorder
{
    public Button Btn;
    public string Key;
    public Bind Def;
    public void Refresh()
    {
        var b = Prefs.GetBind(Key, Def);
        Btn.Text = b != null ? b.Display : "Not set";
    }
}

public partial class MainForm
{
    Panel settingsPanel;
    FlowLayoutPanel col;
    Label hotStatus, opacityVal, adLabel, adHeader;
    Button adSiteBtn;
    TextBox adAllowBox, adCustomBox, adHideBox;
    TrackBar opacityBar;
    FlowLayoutPanel seeBox;
    TextBox startBox;
    readonly List<Action> syncers = new List<Action>();
    readonly List<BindRecorder> recorders = new List<BindRecorder>();
    bool syncing;
    BindRecorder activeRec;

    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

    // ------------------------------------------------------------------ small builders
    Label MkLabel(string text, bool bold = false, bool small = false)
    {
        var l = new Label
        {
            Text = text, AutoSize = true, BackColor = Color.Transparent,
            ForeColor = small ? Theme.Sub : Theme.Fg,
            Margin = new Padding(0, bold ? S(12) : S(2), 0, S(2)),
            Font = bold ? Theme.Bold : (small ? Theme.Small : Theme.UI)
        };
        if (small) l.MaximumSize = new Size(S(440), 0);
        return l;
    }

    CheckBox MkCheck(string text, string key)
    {
        var cb = new CheckBox
        {
            Text = text, AutoSize = true, BackColor = Color.Transparent, ForeColor = Theme.Fg,
            Margin = new Padding(0, S(3), 0, S(3)), MaximumSize = new Size(S(440), 0)
        };
        cb.CheckedChanged += (s, e) => { if (!syncing) OnPref(key, cb.Checked); };
        syncers.Add(() => cb.Checked = Prefs.Flag(key));
        return cb;
    }

    Button MkButton(string text, Action click, int width = 0)
    {
        var b = new Button
        {
            Text = text, FlatStyle = FlatStyle.Flat, BackColor = Theme.Card, ForeColor = Theme.Fg,
            UseVisualStyleBackColor = false, AutoSize = width == 0, Margin = new Padding(0, S(3), S(6), S(3)),
            Padding = new Padding(S(8), S(2), S(8), S(2))
        };
        if (width > 0) b.Width = S(width);
        b.FlatAppearance.BorderColor = Theme.Hover;
        b.FlatAppearance.MouseOverBackColor = Theme.Hover;
        b.Click += (s, e) => click();
        return b;
    }

    FlowLayoutPanel Row(string label, Control c)
    {
        var r = new FlowLayoutPanel
        {
            AutoSize = true, FlowDirection = FlowDirection.LeftToRight, WrapContents = false,
            BackColor = Color.Transparent, Margin = new Padding(0, S(2), 0, S(2))
        };
        var l = new Label
        {
            Text = label, Width = S(170), AutoSize = false, Height = S(26), TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = Theme.Fg, BackColor = Color.Transparent, Margin = Padding.Empty
        };
        c.Margin = new Padding(0, S(1), 0, S(1));
        r.Controls.Add(l);
        r.Controls.Add(c);
        return r;
    }

    ComboBox MkCombo(string[] items, Func<int> get, Action<int> set)
    {
        var c = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList, Width = S(200),
            BackColor = Theme.Card, ForeColor = Theme.Fg, FlatStyle = FlatStyle.Flat
        };
        c.Items.AddRange(items);
        syncers.Add(() => { int i = get(); c.SelectedIndex = Math.Clamp(i, 0, items.Length - 1); });
        c.SelectedIndexChanged += (s, e) => { if (!syncing && c.SelectedIndex >= 0) set(c.SelectedIndex); };
        return c;
    }

    // ------------------------------------------------------------------ the settings panel
    void BuildSettings()
    {
        settingsPanel = new Panel
        {
            Dock = DockStyle.Fill, BackColor = Theme.Bg, AutoScroll = true, Visible = false,
            Padding = new Padding(S(18), S(10), S(18), S(18))
        };
        col = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink, Dock = DockStyle.Top, BackColor = Theme.Bg
        };
        settingsPanel.Controls.Add(col);
        webHost.Controls.Add(settingsPanel);

        // header
        var head = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.LeftToRight, BackColor = Color.Transparent };
        head.Controls.Add(new Label { Text = "Settings", Font = new Font("Segoe UI", 14f, FontStyle.Bold), AutoSize = true,
            ForeColor = Theme.Fg, Margin = new Padding(0, 0, S(20), 0) });
        head.Controls.Add(MkButton("Done", () => ToggleSettings()));
        col.Controls.Add(head);

        // shortcuts
        col.Controls.Add(MkLabel("Global shortcuts (work even while another app is focused)", bold: true));
        foreach (var a in actions)
        {
            var rec = new BindRecorder { Key = a.Key, Def = a.Def };
            rec.Btn = MkButton("", () => StartRecording(rec), 170);
            rec.Btn.Leave += (s, e) => { if (activeRec == rec) { activeRec = null; rec.Refresh(); } };
            recorders.Add(rec);
            col.Controls.Add(Row(a.Title, rec.Btn));
            rec.Refresh();
        }
        hotStatus = MkLabel("", small: true);
        col.Controls.Add(hotStatus);
        col.Controls.Add(MkLabel("Click a shortcut, then press the new keys (must include Ctrl or Alt). Delete clears it. Esc cancels.", small: true));

        // window
        col.Controls.Add(MkLabel("Window", bold: true));
        opacityBar = new TrackBar { Minimum = 30, Maximum = 100, TickStyle = TickStyle.None, Width = S(200), Height = S(28), BackColor = Theme.Bg };
        opacityVal = new Label { AutoSize = true, ForeColor = Theme.Fg, BackColor = Color.Transparent, Margin = new Padding(S(6), S(6), 0, 0) };
        opacityBar.ValueChanged += (s, e) =>
        {
            if (syncing) return;
            Prefs.Opacity = opacityBar.Value / 100.0;
            opacityVal.Text = opacityBar.Value + "%";
            ApplyOpacity();
            UpdateSeeBox();
        };
        var opRow = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, BackColor = Color.Transparent };
        opRow.Controls.Add(opacityBar);
        opRow.Controls.Add(opacityVal);
        col.Controls.Add(Row("Opacity", opRow));

        seeBox = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, BackColor = Color.Transparent };
        seeBox.Controls.Add(MkCheck("See-through (click through the page to the windows behind)", "seeThrough"));
        seeBox.Controls.Add(MkLabel("Only the page area lets clicks through. The toolbar, tabs and bookmarks bar stay solid, " +
            "and holding Alt makes the whole window solid. Available at 80% opacity or lower. Press Done to try it.", small: true));
        col.Controls.Add(seeBox);

        col.Controls.Add(MkCheck("Hide from screenshots and screen sharing", "hideFromCapture"));
        col.Controls.Add(MkCheck("Never take focus (typing keeps going to your other app)", "neverFocus"));
        col.Controls.Add(MkCheck("Hide the window when I click another program", "hideOnBlur"));
        col.Controls.Add(MkCheck("Show bookmarks bar", "bookmarksBar"));
        col.Controls.Add(MkCheck("Reopen last tabs on launch (saves page addresses on this PC)", "restoreTabs"));
        col.Controls.Add(MkCheck("Start pinned on top", "startPinned"));
        col.Controls.Add(MkCheck("Start hidden (use your show/hide shortcut or the tray icon)", "startHidden"));
        col.Controls.Add(MkCheck("Pause video and audio when hiding", "pauseOnHide"));
        col.Controls.Add(MkCheck("Mute audio when hiding", "muteOnHide"));
        col.Controls.Add(MkCheck("Show tray icon", "trayIcon"));

        var auto = new CheckBox { Text = "Start with Windows", AutoSize = true, BackColor = Color.Transparent, ForeColor = Theme.Fg, Margin = new Padding(0, S(3), 0, S(3)) };
        auto.CheckedChanged += (s, e) => { if (!syncing) SetAutostart(auto.Checked); };
        syncers.Add(() => auto.Checked = GetAutostart());
        col.Controls.Add(auto);

        var corners = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.LeftToRight, WrapContents = true, MaximumSize = new Size(S(460), 0), BackColor = Color.Transparent };
        corners.Controls.Add(MkButton("Top left", () => SnapCorner(0)));
        corners.Controls.Add(MkButton("Top right", () => SnapCorner(1)));
        corners.Controls.Add(MkButton("Bottom left", () => SnapCorner(2)));
        corners.Controls.Add(MkButton("Bottom right", () => SnapCorner(3)));
        col.Controls.Add(Row("Move to corner", corners));
        col.Controls.Add(MkButton("Reset window size and position", () => { if (covering) ToggleCover(); ResetFrame(); }));

        // ad blocker
        adHeader = MkLabel("Ad blocker", bold: true);
        col.Controls.Add(adHeader);
        col.Controls.Add(MkCheck("Block ads and trackers (master switch)", "adblock"));
        adSiteBtn = MkButton("Pause ad blocker on this site", () => ToggleAllowHost(CurrentHost()));
        col.Controls.Add(adSiteBtn);
        adLabel = MkLabel("", small: true);
        col.Controls.Add(adLabel);
        col.Controls.Add(MkButton("Reset counters", () => { AdBlock.ResetCounts(); UpdateAdStats(); UpdateShield(); }));

        col.Controls.Add(MkLabel("What to block", bold: true));
        col.Controls.Add(MkCheck("Ads and ad networks", "ab_ads"));
        col.Controls.Add(MkCheck("Pop-up and pop-under ad networks", "ab_popups"));
        col.Controls.Add(MkCheck("Trackers and analytics (Google Analytics, Hotjar ...)", "ab_trackers"));
        col.Controls.Add(MkCheck("Error and performance trackers (Sentry, Bugsnag ...)", "ab_errors"));
        col.Controls.Add(MkCheck("Ad images and scripts recognised by file name (/ads/, banner sizes ...)", "ab_paths"));
        col.Controls.Add(MkCheck("Hide leftover empty ad boxes", "ab_cosmetic"));
        col.Controls.Add(MkCheck("Skip YouTube video ads", "ab_youtube"));
        col.Controls.Add(MkCheck("Hide cookie-consent banners (may not work on every site)", "ab_cookies"));
        col.Controls.Add(MkCheck("Block pop-up windows that open without a click (can break some sign-in flows)", "ab_popupwin"));

        col.Controls.Add(MkLabel("Privacy", bold: true));
        col.Controls.Add(MkCheck("Remove tracking codes from links (utm_*, fbclid, gclid ...)", "ab_strip"));
        col.Controls.Add(MkCheck("Send Do Not Track and Global Privacy Control", "ab_dnt"));

        col.Controls.Add(MkLabel("Your own lists", bold: true));
        adAllowBox = MkListBox();
        col.Controls.Add(MkLabel("Never block on these sites (one per line):", small: true));
        col.Controls.Add(adAllowBox);
        adAllowBox.Leave += (s, e) => ApplyAdLists();
        syncers.Add(() => adAllowBox.Text = string.Join("\r\n", Prefs.AdAllow));

        adCustomBox = MkListBox();
        col.Controls.Add(MkLabel("Always block these domains (one per line):", small: true));
        col.Controls.Add(adCustomBox);
        adCustomBox.Leave += (s, e) => ApplyAdLists();
        syncers.Add(() => adCustomBox.Text = string.Join("\r\n", Prefs.AdCustom));

        adHideBox = MkListBox();
        col.Controls.Add(MkLabel("Always hide these page elements (CSS selectors, one per line, e.g. .promo-bar):", small: true));
        col.Controls.Add(adHideBox);
        adHideBox.Leave += (s, e) => ApplyAdLists();
        syncers.Add(() => adHideBox.Text = Prefs.AdHide.Replace("\n", "\r\n").Replace("\r\r\n", "\r\n"));

        col.Controls.Add(MkButton("Apply lists", () => ApplyAdLists(true)));
        col.Controls.Add(MkLabel("Blocks known ad and tracker servers, hides leftover ad boxes and skips YouTube video ads. " +
            "If a site breaks, pause the blocker on that site (the AD button in the toolbar) or switch a category off.", small: true));

        // browser
        col.Controls.Add(MkLabel("Browser", bold: true));
        var engineNames = new List<string>();
        foreach (var en in Engines.List) engineNames.Add(en.Name);
        col.Controls.Add(Row("Search engine", MkCombo(engineNames.ToArray(), () => Prefs.EngineIndex,
            i => { Prefs.EngineIndex = i; if (CurTab != null && CurTab.IsHome) ShowHome(CurTab); })));

        var uaNames = new List<string>();
        foreach (var u in Prefs.Uas) uaNames.Add(u.Name);
        col.Controls.Add(Row("Browser identity", MkCombo(uaNames.ToArray(), () => Prefs.UaIndex,
            i =>
            {
                Prefs.UaIndex = i;
                foreach (var t in tabs) ApplyUA(t);
                if (CurTab != null && !CurTab.IsHome) DoReload();
            })));

        col.Controls.Add(Row("Page zoom", MkCombo(Prefs.ZoomNames, () => Prefs.ZoomIndex,
            i => { Prefs.ZoomIndex = i; foreach (var t in tabs) t.Web.ZoomFactor = Prefs.Zooms[i]; })));

        startBox = new TextBox { Width = S(200), BackColor = Theme.Card, ForeColor = Theme.Fg, BorderStyle = BorderStyle.FixedSingle, PlaceholderText = "Blank = Home page" };
        startBox.Leave += (s, e) => Prefs.StartPage = startBox.Text.Trim();
        startBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Prefs.StartPage = startBox.Text.Trim(); } };
        syncers.Add(() => startBox.Text = Prefs.StartPage);
        col.Controls.Add(Row("Start page", startBox));

        col.Controls.Add(MkButton("Clear browsing data\u2026", () => ClearBrowsingData()));
        col.Controls.Add(MkButton("Remove all bookmarks\u2026", () => RemoveAllBookmarks()));

        col.Controls.Add(MkLabel("App", bold: true));
        col.Controls.Add(MkButton("Quit HiddenBrowser", () => Close()));

        col.Controls.Add(MkLabel("Shortcuts inside the window: Ctrl+T new tab, Ctrl+W close tab, Ctrl+Shift+T reopen tab, " +
            "Ctrl+1\u20139 jump to tab, Ctrl+Tab next tab, Ctrl+L address bar, Ctrl+D bookmark, Ctrl+F find, " +
            "Ctrl+Shift+B bookmarks bar, Ctrl+Shift+W hide, Ctrl+, settings.", small: true));

        UpdateSeeBox();
    }

    TextBox MkListBox()
    {
        return new TextBox
        {
            Multiline = true, AcceptsReturn = true, ScrollBars = ScrollBars.Vertical, WordWrap = true,
            Width = S(420), Height = S(70), BackColor = Theme.Card, ForeColor = Theme.Fg,
            BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(0, S(2), 0, S(6))
        };
    }

    string lastAdLists = "";

    void ApplyAdLists(bool force = false)
    {
        if (syncing || adAllowBox == null) return;
        string sig = adAllowBox.Text + "|" + adCustomBox.Text + "|" + adHideBox.Text;
        if (!force && sig == lastAdLists) return;
        lastAdLists = sig;
        Prefs.AdAllow = AdBlock.ParseDomains(adAllowBox.Text);
        Prefs.AdCustom = AdBlock.ParseDomains(adCustomBox.Text);
        Prefs.AdHide = string.Join("\n", AdBlock.SplitLines(adHideBox.Text));
        Prefs.Save();
        RefreshAllAdScripts();
        UpdateShield();
        if (CurTab != null && !CurTab.IsHome) DoReload();
    }

    void UpdateAdStats()
    {
        if (adLabel == null) return;
        var parts = new List<string>();
        foreach (var kv in AdBlock.Counts) parts.Add(kv.Key + " " + kv.Value);
        adLabel.Text = "Blocked this session: " + AdBlock.Total +
            (parts.Count > 0 ? " (" + string.Join(", ", parts) + ")" : "") + ".  All time: " + Prefs.AdTotal + ".";
    }

    void UpdateSeeBox()
    {
        if (seeBox != null) seeBox.Visible = Prefs.Opacity * 100.0 <= Prefs.SeeThreshold;
    }

    void SyncSettings()
    {
        if (settingsPanel == null) return;
        syncing = true;
        try
        {
            foreach (var s in syncers) s();
            int v = (int)Math.Round(Prefs.Opacity * 100);
            opacityBar.Value = Math.Clamp(v, opacityBar.Minimum, opacityBar.Maximum);
            opacityVal.Text = opacityBar.Value + "%";
            UpdateAdStats();
            foreach (var r in recorders) r.Refresh();
        }
        finally { syncing = false; }
        lastAdLists = adAllowBox.Text + "|" + adCustomBox.Text + "|" + adHideBox.Text;
        UpdateSeeBox();
        UpdateHotStatus();
        UpdateShield();
    }

    void ToggleSettings()
    {
        settingsOpen = !settingsOpen;
        settingsPanel.Visible = settingsOpen;
        if (settingsOpen)
        {
            SyncSettings();
            settingsPanel.BringToFront();
            SetIgnore(false);
        }
        ApplyKeyPolicy();
        btnGear.ForeColor = settingsOpen ? Theme.Accent : Theme.Fg;
        if (!settingsOpen)
        {
            activeRec = null;
            foreach (var r in recorders) r.Refresh();
            TickMouse();
            if (CurTab != null && AllowKey && CurTab.Web.CoreWebView2 != null) CurTab.Web.Focus();
        }
    }

    void OnPref(string key, bool v)
    {
        Prefs.SetFlag(key, v);
        if (key == "adblock" || key.StartsWith("ab_"))
        {
            RefreshAllAdScripts();
            UpdateShield();
            if (key != "ab_dnt" && CurTab != null && !CurTab.IsHome) DoReload();
            return;
        }
        switch (key)
        {
            case "hideFromCapture": ApplyCapture(); break;
            case "neverFocus": ApplyKeyPolicy(); break;
            case "trayIcon": UpdateTray(); break;
            case "seeThrough": TickMouse(); break;
            case "bookmarksBar": RefreshBookmarksBar(); break;
            case "restoreTabs": SaveTabs(); break;
        }
    }

    void RemoveAllBookmarks()
    {
        var ans = MessageBox.Show(this, "Remove all bookmarks?", "Bookmarks", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
        if (ans != DialogResult.OK) return;
        Prefs.Bookmarks.Clear();
        Prefs.Save();
        BookmarksChanged();
    }

    // ------------------------------------------------------------------ shortcut recording
    void StartRecording(BindRecorder rec)
    {
        if (activeRec != null) activeRec.Refresh();
        activeRec = rec;
        rec.Btn.Text = "Press keys\u2026";
        rec.Btn.Focus();
    }

    bool HandleRecorderKey(Keys keyData)
    {
        Keys key = keyData & Keys.KeyCode;
        Keys mods = keyData & Keys.Modifiers;
        var rec = activeRec;
        if (key == Keys.ControlKey || key == Keys.ShiftKey || key == Keys.Menu || key == Keys.LWin || key == Keys.RWin) return true;

        if (key == Keys.Escape) { activeRec = null; rec.Refresh(); return true; }
        if (key == Keys.Delete || key == Keys.Back)
        {
            Prefs.SetBind(rec.Key, null);
            activeRec = null; rec.Refresh(); RegisterBinds();
            return true;
        }
        int m = 0;
        if ((mods & Keys.Alt) != 0) m |= 1;
        if ((mods & Keys.Control) != 0) m |= 2;
        if ((mods & Keys.Shift) != 0) m |= 4;
        if ((m & 3) == 0) { System.Media.SystemSounds.Beep.Play(); return true; }

        Prefs.SetBind(rec.Key, new Bind { Key = (int)key, Mods = m });
        activeRec = null;
        rec.Refresh();
        RegisterBinds();
        return true;
    }

    void UpdateHotStatus()
    {
        if (hotStatus == null) return;
        var failed = new List<string>();
        foreach (var a in actions)
        {
            var b = Prefs.GetBind(a.Key, a.Def);
            bool ok;
            if (b != null && hotOk.TryGetValue(a.Id, out ok) && !ok) failed.Add(a.Title);
        }
        if (failed.Count == 0) { hotStatus.Text = "All shortcuts active."; hotStatus.ForeColor = Theme.Sub; }
        else
        {
            hotStatus.Text = "Another app is using the shortcut for: " + string.Join(", ", failed) + ". Pick a different one.";
            hotStatus.ForeColor = Color.IndianRed;
        }
    }

    // ------------------------------------------------------------------ start with Windows
    bool GetAutostart()
    {
        try
        {
            using (var k = Registry.CurrentUser.OpenSubKey(RunKey))
                return k != null && k.GetValue("HiddenBrowser") != null;
        }
        catch { return false; }
    }

    void SetAutostart(bool on)
    {
        try
        {
            using (var k = Registry.CurrentUser.OpenSubKey(RunKey, true))
            {
                if (k == null) return;
                if (on) k.SetValue("HiddenBrowser", "\"" + Application.ExecutablePath + "\"");
                else k.DeleteValue("HiddenBrowser", false);
            }
        }
        catch { }
    }
}
