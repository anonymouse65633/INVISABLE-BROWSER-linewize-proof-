HiddenBrowser for Windows
=========================

Same app as the Mac version: tabs, bookmarks bar, see-through click-through mode,
global shortcuts, pin on top, cover screen, hide from screenshots, never-focus mode,
tray icon, and a built-in ad blocker with per-site pause, categories and your own lists.

INSTALL + BUILD (one click)
  Double-click build.bat.  It installs anything missing (the .NET 8 SDK and the Edge
  WebView2 Runtime, using winget), builds the app, and puts a single HiddenBrowser.exe in
  your Downloads folder, then opens it.  Needs Windows 10 (2004+) or Windows 11 and internet
  for the first build.  Move or copy the exe anywhere you like afterwards.

DEFAULT GLOBAL SHORTCUTS (work in any app; change them in Settings)
  Ctrl+Alt+H   show / hide
  Ctrl+Alt+D   panic hide (pauses and mutes)
  Ctrl+Alt+F   pin on top
  Ctrl+Alt+G   cover the screen
  Ctrl+Alt+C   click-through (whole window)
  Ctrl+Alt+T   never-focus mode

INSIDE THE WINDOW
  Ctrl+T new tab        Ctrl+W close tab        Ctrl+Shift+T reopen closed tab
  Ctrl+1..9 jump to tab Ctrl+Tab next tab       Ctrl+L address bar
  Ctrl+D bookmark       Ctrl+F find, Ctrl+G next Ctrl+Shift+B bookmarks bar
  Ctrl+Shift+W hide     Ctrl+Shift+F cover      Ctrl+, settings
  Alt+Left / Alt+Right back / forward

SEE-THROUGH
  Settings > Opacity 80% or lower > tick See-through > press Done.
  The page area lets clicks through; toolbar, tabs and bookmarks bar stay solid.
  Hold Alt to make the whole window solid.

DIFFERENCES FROM THE MAC VERSION
  - Uses the Edge (Chromium) engine instead of WebKit, so the "Safari" identity is
    optional and the default is Edge.
  - Windows has no single "all desktops" flag. When pinned, the app moves itself to
    whichever virtual desktop you switch to (it can take a fraction of a second).
  - Not shown in the taskbar. Turn on the tray icon in Settings if you want one.
  - Settings are stored in %AppData%\HiddenBrowser\settings.json.

AD BLOCKER
  The AD button in the toolbar (blue = on, grey = paused/off) opens a menu: turn the blocker off,
  pause it on the current site, or jump to its settings.
  Settings > Ad blocker lets you switch categories on/off (ads, pop-up networks, trackers,
  error trackers, ad files by name, ad boxes, YouTube ads, cookie banners, pop-ups without a click),
  remove tracking codes from links, send Do Not Track, and keep your own lists:
  sites to never block on, domains to always block, and page elements (CSS selectors) to always hide.
  It also shows how many requests were blocked this session and all time.

WINDOWS-ONLY EXTRAS
  - "Hide the window when I click another program" (Settings > Window).
  - Block pop-up windows that open without a click.
  - Tray icon with Show/Hide, Pin, Cover, Settings, Quit.
  - Start with Windows.
