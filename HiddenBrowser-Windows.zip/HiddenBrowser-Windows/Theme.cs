using System.Drawing.Drawing2D;
using Microsoft.Win32;

namespace HiddenBrowser;

static class Theme
{
    public static bool Dark;
    public static Color Bg, Bar, Bar2, Fg, Sub, Card, Hover, Accent;
    public static Font UI, Bold, Small, Icons, IconsSmall;

    public static void Init()
    {
        try
        {
            using var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
            object v = k?.GetValue("AppsUseLightTheme");
            Dark = v is int i && i == 0;
        }
        catch { Dark = true; }

        if (Dark)
        {
            Bg = Color.FromArgb(32, 33, 36);
            Bar = Color.FromArgb(41, 42, 45);
            Bar2 = Color.FromArgb(48, 49, 52);
            Fg = Color.FromArgb(232, 234, 237);
            Sub = Color.FromArgb(154, 160, 166);
            Card = Color.FromArgb(60, 64, 67);
            Hover = Color.FromArgb(72, 75, 79);
            Accent = Color.FromArgb(138, 180, 248);
        }
        else
        {
            Bg = Color.White;
            Bar = Color.FromArgb(241, 243, 244);
            Bar2 = Color.FromArgb(232, 234, 237);
            Fg = Color.FromArgb(32, 33, 36);
            Sub = Color.FromArgb(95, 99, 104);
            Card = Color.FromArgb(255, 255, 255);
            Hover = Color.FromArgb(218, 220, 224);
            Accent = Color.FromArgb(26, 115, 232);
        }
        UI = new Font("Segoe UI", 9f);
        Bold = new Font("Segoe UI", 10f, FontStyle.Bold);
        Small = new Font("Segoe UI", 8.5f);
        Icons = new Font("Segoe MDL2 Assets", 10f);
        IconsSmall = new Font("Segoe MDL2 Assets", 8f);
    }

    public static void FillRound(Graphics g, Brush b, Rectangle r, int rad)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        int d = rad * 2;
        using var p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        g.FillPath(b, p);
    }
}
